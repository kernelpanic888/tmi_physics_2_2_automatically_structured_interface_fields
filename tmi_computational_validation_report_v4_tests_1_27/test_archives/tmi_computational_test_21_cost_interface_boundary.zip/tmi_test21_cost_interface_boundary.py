# TMI Computational Test 21: Cost-Interface Boundary Test
print('See CSV, JSON, and PNG files in this archive.')
