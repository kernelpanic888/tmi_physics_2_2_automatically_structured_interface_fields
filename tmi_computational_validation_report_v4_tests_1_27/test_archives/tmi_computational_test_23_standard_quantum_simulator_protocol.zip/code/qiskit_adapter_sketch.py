"""
Qiskit adapter sketch for Test 23.

The execution environment used to generate the attached results did not include Qiskit.
This file shows the intended mapping:

- CIRCUITS -> QuantumCircuit
- noise_model -> qiskit_aer.noise.NoiseModel
- base/standard/tmi -> different noise parameters
- metric -> counts["000"] / shots or density-matrix save probability

Pseudo-code:

from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error, phase_damping_error, amplitude_damping_error

def build_circuit(spec):
    qc = QuantumCircuit(3, 3)
    for op in spec:
        if op[0] == "H": qc.h(op[1])
        elif op[0] == "X": qc.x(op[1])
        elif op[0] == "S": qc.s(op[1])
        elif op[0] == "CNOT": qc.cx(op[1], op[2])
        elif op[0] == "IDLE": qc.id(0); qc.id(1); qc.id(2)
    qc.measure([0,1,2], [0,1,2])
    return qc

def run_qiskit(qc, noise_model, shots=4096):
    sim = AerSimulator(noise_model=noise_model)
    tqc = transpile(qc, sim)
    result = sim.run(tqc, shots=shots).result()
    counts = result.get_counts()
    return counts.get("000", 0) / shots
"""
