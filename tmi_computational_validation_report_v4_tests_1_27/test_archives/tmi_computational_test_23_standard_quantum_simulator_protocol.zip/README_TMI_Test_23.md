# TMI Computational Test 23: Standard Quantum Simulator Validation Protocol

## Purpose

Tests 1-22 used internal computational models. Test 23 starts the external-simulator
validation path by rewriting the validation in a standard quantum simulator style:

- declarative circuit specifications;
- backend-independent density-matrix execution;
- explicit Kraus/noise channels;
- canonical noise models.

## Runtime availability

| Package | Available |
|---|---:|
| qiskit | False |
| cirq | False |
| qutip | False |
| numpy | True |
| scipy | True |

Because Qiskit/Cirq/QuTiP are not installed in this runtime, the attached results were
generated with a portable standalone density-matrix backend. A Qiskit adapter sketch is
included in `code/qiskit_adapter_sketch.py`.

## Main result

| Metric | Value |
|---|---:|
| Circuit families | 4 |
| Noise models | 4 |
| Total runs | 224 |
| Mean P_base | 0.557323 |
| Mean P_standard | 0.586857 |
| Mean P_TMI | 0.628228 |
| Mean delta TMI - standard | 0.041371 |
| 95% CI delta | [0.034733, 0.047597] |
| Pr(TMI > standard) | 0.750000 |
| Noise models passed | 4 / 4 |
| Circuit/noise cells passed | 12 / 16 |

## Results by noise model

| Noise model | Base | Standard | TMI | Delta TMI-standard | Pr(TMI>standard) | Passed |
|---|---:|---:|---:|---:|---:|---:|
| amplitude_damping | 0.553672 | 0.573604 | 0.633612 | 0.060008 | 0.750000 | True |
| dephasing | 0.521143 | 0.563364 | 0.616864 | 0.053499 | 0.750000 | True |
| depolarizing | 0.622763 | 0.644530 | 0.661826 | 0.017296 | 0.750000 | True |
| mixed | 0.531713 | 0.565930 | 0.600610 | 0.034680 | 0.750000 | True |

## Interpretation

This test is a bridge toward true Qiskit/Cirq/QuTiP validation. It confirms that the
adaptive interface mechanism can be expressed in a backend-independent standard
quantum-simulator protocol.

## Scientific caution

This is not yet a Qiskit-Aer or Cirq execution, because those packages are unavailable
in the current runtime. The next step is to run the same declarative circuits and noise
profiles in a real external simulator environment.
