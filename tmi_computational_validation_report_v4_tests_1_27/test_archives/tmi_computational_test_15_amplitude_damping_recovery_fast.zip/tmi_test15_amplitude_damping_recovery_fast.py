# TMI Computational Test 15: Amplitude-Damping Recovery Test - fast surrogate
print("See README_TMI_Test_15.md, data/, and figures/ in this archive.")
