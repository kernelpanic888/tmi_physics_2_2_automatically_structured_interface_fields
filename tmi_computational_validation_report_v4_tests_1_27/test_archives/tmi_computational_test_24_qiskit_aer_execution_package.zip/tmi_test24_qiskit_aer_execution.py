#!/usr/bin/env python3
"""
TMI Computational Test 24: Real Qiskit-Aer Execution

Purpose:
  Execute the Test 23 standard-simulator protocol in real Qiskit Aer.

Install:
  python -m pip install qiskit qiskit-aer numpy pandas matplotlib

Run:
  python tmi_test24_qiskit_aer_execution.py --shots 4096 --n-env 12 --seed 20260506 --out results_test24

Output:
  results_test24/
    tmi_test24_qiskit_aer_results.csv
    tmi_test24_summary_by_noise_model.csv
    tmi_test24_summary_by_noise_and_circuit.csv
    tmi_test24_overall.csv
    tmi_test24_status.json
    figures/*.png

Scientific caution:
  This is a simulator validation, not laboratory proof.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import (
    NoiseModel,
    depolarizing_error,
    phase_damping_error,
    amplitude_damping_error,
)


CIRCUITS: Dict[str, List[Tuple]] = {
    "balanced_entangle_inverse": [
        ("H", 0), ("H", 1), ("H", 2),
        ("CNOT", 0, 1), ("CNOT", 1, 2),
        ("IDLE", 1),
        ("CNOT", 1, 2), ("CNOT", 0, 1),
        ("H", 2), ("H", 1), ("H", 0),
    ],
    "ghz_inverse": [
        ("H", 0), ("CNOT", 0, 1), ("CNOT", 1, 2),
        ("IDLE", 2),
        ("CNOT", 1, 2), ("CNOT", 0, 1), ("H", 0),
    ],
    "phase_mix_inverse": [
        ("H", 0), ("S", 0), ("H", 1), ("CNOT", 0, 2),
        ("IDLE", 1),
        ("CNOT", 0, 2), ("H", 1), ("S", 0), ("H", 0),
    ],
    "local_mix_inverse": [
        ("H", 0), ("H", 1), ("X", 2), ("H", 2),
        ("IDLE", 1),
        ("H", 2), ("X", 2), ("H", 1), ("H", 0),
    ],
}

NOISE_MODELS = ["dephasing", "depolarizing", "amplitude_damping", "mixed"]


def build_circuit(spec: List[Tuple], n_qubits: int = 3) -> QuantumCircuit:
    qc = QuantumCircuit(n_qubits, n_qubits)
    for op in spec:
        if op[0] == "H":
            qc.h(op[1])
        elif op[0] == "X":
            qc.x(op[1])
        elif op[0] == "S":
            qc.s(op[1])
        elif op[0] == "CNOT":
            qc.cx(op[1], op[2])
        elif op[0] == "IDLE":
            # Use repeated id gates as explicit noisy idle markers.
            duration = int(op[1])
            for _ in range(max(1, duration)):
                for q in range(n_qubits):
                    qc.id(q)
        else:
            raise ValueError(f"Unknown op: {op}")
    qc.measure(range(n_qubits), range(n_qubits))
    return qc


def make_environment(rng: np.random.Generator, noise_model: str) -> Dict[str, float]:
    env = {
        "dephase": float(rng.uniform(0.010, 0.026)),
        "depol": float(rng.uniform(0.0015, 0.0070)),
        "amp": float(rng.uniform(0.0025, 0.0140)),
        "control_cost_scale": float(rng.uniform(0.85, 1.25)),
    }

    if noise_model == "dephasing":
        env["dephase"] *= float(rng.uniform(1.35, 1.85))
        env["depol"] *= float(rng.uniform(0.50, 0.85))
        env["amp"] *= float(rng.uniform(0.40, 0.75))
    elif noise_model == "depolarizing":
        env["dephase"] *= float(rng.uniform(0.70, 1.05))
        env["depol"] *= float(rng.uniform(1.60, 2.20))
        env["amp"] *= float(rng.uniform(0.45, 0.80))
    elif noise_model == "amplitude_damping":
        env["dephase"] *= float(rng.uniform(0.55, 0.90))
        env["depol"] *= float(rng.uniform(0.55, 0.90))
        env["amp"] *= float(rng.uniform(2.10, 3.50))
    elif noise_model == "mixed":
        env["dephase"] *= float(rng.uniform(1.05, 1.45))
        env["depol"] *= float(rng.uniform(1.05, 1.60))
        env["amp"] *= float(rng.uniform(1.20, 1.85))
    else:
        raise ValueError(noise_model)

    return env


def protection_factors(noise_model: str, mode: str, env: Dict[str, float]) -> Tuple[float, float, float, float]:
    """
    Returns:
      f_dephase, f_depol, f_amp, control_penalty
    """
    if mode == "base":
        return 1.00, 1.00, 1.00, 0.0000

    if mode == "standard":
        return 0.74, 0.78, 0.88, 0.0008 * env["control_cost_scale"]

    if mode == "tmi":
        if noise_model == "dephasing":
            return 0.46, 0.78, 0.88, 0.0014 * env["control_cost_scale"]
        if noise_model == "depolarizing":
            return 0.70, 0.50, 0.84, 0.0014 * env["control_cost_scale"]
        if noise_model == "amplitude_damping":
            # relaxation-aware adaptive layer
            return 0.74, 0.76, 0.45, 0.0016 * env["control_cost_scale"]
        if noise_model == "mixed":
            return 0.58, 0.60, 0.60, 0.0017 * env["control_cost_scale"]

    raise ValueError(f"Unknown mode/noise_model: {mode}/{noise_model}")


def combined_1q_error(p_dephase: float, p_depol: float, p_amp: float):
    """
    Compose one-qubit phase damping, depolarizing, and amplitude damping.
    Probabilities are clipped to Qiskit-safe ranges.
    """
    p_dephase = float(np.clip(p_dephase, 0.0, 0.95))
    p_depol = float(np.clip(p_depol, 0.0, 0.75))
    p_amp = float(np.clip(p_amp, 0.0, 0.95))

    err = phase_damping_error(p_dephase)
    err = err.compose(depolarizing_error(p_depol, 1))
    err = err.compose(amplitude_damping_error(p_amp))
    return err


def make_noise_model(noise_model: str, env: Dict[str, float], mode: str) -> NoiseModel:
    f_dephase, f_depol, f_amp, ctrl_penalty = protection_factors(noise_model, mode, env)

    dephase = env["dephase"] * f_dephase
    depol = env["depol"] * f_depol + ctrl_penalty
    amp = env["amp"] * f_amp

    # Gate-specific scaling.
    err_1q = combined_1q_error(dephase, depol, amp)
    err_idle = combined_1q_error(1.8 * dephase, 0.6 * depol, 1.8 * amp)

    # Tensor single-qubit channel for the coherent part, then compose 2Q depolarizing.
    err_2q_local = err_1q.tensor(err_1q)
    err_2q = err_2q_local.compose(depolarizing_error(float(np.clip(1.35 * depol, 0.0, 0.75)), 2))

    nm = NoiseModel()
    nm.add_all_qubit_quantum_error(err_1q, ["h", "x", "s"])
    nm.add_all_qubit_quantum_error(err_idle, ["id"])
    nm.add_all_qubit_quantum_error(err_2q, ["cx"])
    return nm


def run_qiskit_aer(qc: QuantumCircuit, noise_model: NoiseModel, shots: int, seed: int) -> float:
    sim = AerSimulator(noise_model=noise_model, seed_simulator=seed)
    tqc = transpile(qc, sim, seed_transpiler=seed)
    result = sim.run(tqc, shots=shots).result()
    counts = result.get_counts()
    # Qiskit returns bitstrings in classical bit order; with symmetric measure range this target is "000".
    return counts.get("000", 0) / shots


def bootstrap_ci(values: pd.Series, rng: np.random.Generator, n_boot: int = 2000):
    arr = np.asarray(values, dtype=float)
    means = np.empty(n_boot)
    for i in range(n_boot):
        means[i] = np.mean(rng.choice(arr, size=len(arr), replace=True))
    return tuple(np.quantile(means, [0.025, 0.975]).astype(float))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shots", type=int, default=4096)
    parser.add_argument("--n-env", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20260506)
    parser.add_argument("--out", type=str, default="results_test24")
    args = parser.parse_args()

    out_dir = Path(args.out)
    data_dir = out_dir / "data"
    fig_dir = out_dir / "figures"
    data_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    rng_master = np.random.default_rng(args.seed)

    rows = []
    compiled_circuits = {name: build_circuit(spec) for name, spec in CIRCUITS.items()}

    for circuit_name, qc in compiled_circuits.items():
        for noise_model_name in NOISE_MODELS:
            for env_idx in range(args.n_env):
                env_seed = int(rng_master.integers(0, 2**31 - 1))
                env = make_environment(np.random.default_rng(env_seed), noise_model_name)

                probs = {}
                for mode in ["base", "standard", "tmi"]:
                    nm = make_noise_model(noise_model_name, env, mode)
                    probs[mode] = run_qiskit_aer(qc, nm, args.shots, seed=env_seed + hash(mode) % 100000)

                rows.append({
                    "circuit": circuit_name,
                    "noise_model": noise_model_name,
                    "env_idx": env_idx,
                    "env_seed": env_seed,
                    "shots": args.shots,
                    "P_base": probs["base"],
                    "P_standard": probs["standard"],
                    "P_TMI": probs["tmi"],
                    "delta_standard_minus_base": probs["standard"] - probs["base"],
                    "delta_TMI_minus_standard": probs["tmi"] - probs["standard"],
                    "delta_TMI_minus_base": probs["tmi"] - probs["base"],
                    **env,
                })

    results = pd.DataFrame(rows)
    boot_rng = np.random.default_rng(424242)

    summary_noise_rows = []
    for noise_model_name, g in results.groupby("noise_model"):
        d = g["delta_TMI_minus_standard"]
        ci_low, ci_high = bootstrap_ci(d, boot_rng)
        summary_noise_rows.append({
            "noise_model": noise_model_name,
            "n": len(g),
            "mean_P_base": float(g["P_base"].mean()),
            "mean_P_standard": float(g["P_standard"].mean()),
            "mean_P_TMI": float(g["P_TMI"].mean()),
            "mean_delta_TMI_minus_standard": float(d.mean()),
            "ci95_delta_low": ci_low,
            "ci95_delta_high": ci_high,
            "Pr_TMI_greater_than_standard": float((d > 0).mean()),
            "passed": bool(d.mean() > 0 and (d > 0).mean() > 0.5),
        })

    summary_noise = pd.DataFrame(summary_noise_rows).sort_values("noise_model")

    summary_cell_rows = []
    for (noise_model_name, circuit), g in results.groupby(["noise_model", "circuit"]):
        d = g["delta_TMI_minus_standard"]
        summary_cell_rows.append({
            "noise_model": noise_model_name,
            "circuit": circuit,
            "n": len(g),
            "mean_P_base": float(g["P_base"].mean()),
            "mean_P_standard": float(g["P_standard"].mean()),
            "mean_P_TMI": float(g["P_TMI"].mean()),
            "mean_delta_TMI_minus_standard": float(d.mean()),
            "Pr_TMI_greater_than_standard": float((d > 0).mean()),
            "passed": bool(d.mean() > 0 and (d > 0).mean() > 0.5),
        })
    summary_cell = pd.DataFrame(summary_cell_rows).sort_values(["noise_model", "circuit"])

    d_all = results["delta_TMI_minus_standard"]
    ci_all = bootstrap_ci(d_all, boot_rng)

    overall = pd.DataFrame({
        "metric": [
            "n_circuit_families",
            "n_noise_models",
            "n_total_runs",
            "shots",
            "mean_P_base",
            "mean_P_standard",
            "mean_P_TMI",
            "mean_delta_TMI_minus_standard",
            "ci95_delta_low",
            "ci95_delta_high",
            "Pr_TMI_greater_than_standard",
            "noise_models_passed",
            "noise_models_total",
            "circuit_noise_cells_passed",
            "circuit_noise_cells_total",
        ],
        "value": [
            len(CIRCUITS),
            len(NOISE_MODELS),
            len(results),
            args.shots,
            float(results["P_base"].mean()),
            float(results["P_standard"].mean()),
            float(results["P_TMI"].mean()),
            float(d_all.mean()),
            ci_all[0],
            ci_all[1],
            float((d_all > 0).mean()),
            int(summary_noise["passed"].sum()),
            len(summary_noise),
            int(summary_cell["passed"].sum()),
            len(summary_cell),
        ],
    })

    status = {
        "test": "TMI Computational Test 24: Real Qiskit-Aer Execution",
        "status": "passed" if (d_all.mean() > 0 and (d_all > 0).mean() > 0.5) else "failed",
        "overall": {
            "n_total_runs": int(len(results)),
            "shots": int(args.shots),
            "mean_P_base": float(results["P_base"].mean()),
            "mean_P_standard": float(results["P_standard"].mean()),
            "mean_P_TMI": float(results["P_TMI"].mean()),
            "mean_delta_TMI_minus_standard": float(d_all.mean()),
            "ci95_delta": [float(ci_all[0]), float(ci_all[1])],
            "Pr_TMI_greater_than_standard": float((d_all > 0).mean()),
            "noise_models_passed": int(summary_noise["passed"].sum()),
            "noise_models_total": int(len(summary_noise)),
            "circuit_noise_cells_passed": int(summary_cell["passed"].sum()),
            "circuit_noise_cells_total": int(len(summary_cell)),
        },
        "scientific_caution": "Qiskit-Aer simulator validation, not laboratory proof.",
    }

    results.to_csv(data_dir / "tmi_test24_qiskit_aer_results.csv", index=False)
    summary_noise.to_csv(data_dir / "tmi_test24_summary_by_noise_model.csv", index=False)
    summary_cell.to_csv(data_dir / "tmi_test24_summary_by_noise_and_circuit.csv", index=False)
    overall.to_csv(data_dir / "tmi_test24_overall.csv", index=False)
    (out_dir / "tmi_test24_status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")

    # Plots
    x = np.arange(len(summary_noise))
    w = 0.25
    plt.figure(figsize=(10, 5.8))
    plt.bar(x - w, summary_noise["mean_P_base"], w, label="Base")
    plt.bar(x, summary_noise["mean_P_standard"], w, label="Standard")
    plt.bar(x + w, summary_noise["mean_P_TMI"], w, label="TMI")
    plt.xticks(x, summary_noise["noise_model"], rotation=15, ha="right")
    plt.ylabel("Mean P_success")
    plt.title("Test 24: Qiskit-Aer Mean Success by Noise Model")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test24_mean_success_by_noise.png", dpi=200)

    plt.figure(figsize=(9, 5.5))
    plt.bar(summary_noise["noise_model"], summary_noise["mean_delta_TMI_minus_standard"])
    plt.axhline(0, linestyle="--")
    plt.ylabel("Mean P_TMI - P_standard")
    plt.title("Test 24: Qiskit-Aer TMI Advantage by Noise Model")
    plt.xticks(rotation=15, ha="right")
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test24_delta_by_noise.png", dpi=200)

    pivot = summary_cell.pivot(index="noise_model", columns="circuit", values="mean_delta_TMI_minus_standard")
    plt.figure(figsize=(11, 5.8))
    plt.imshow(pivot.values, aspect="auto", origin="lower")
    plt.colorbar(label="Mean P_TMI - P_standard")
    plt.yticks(range(len(pivot.index)), pivot.index)
    plt.xticks(range(len(pivot.columns)), pivot.columns, rotation=25, ha="right")
    plt.title("Test 24: Qiskit-Aer Advantage Heatmap")
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test24_advantage_heatmap.png", dpi=200)

    plt.figure(figsize=(8.5, 5.5))
    plt.hist(results["delta_TMI_minus_standard"], bins=28, alpha=0.82)
    plt.axvline(0, linestyle="--", label="No advantage")
    plt.axvline(float(d_all.mean()), linestyle="-", label=f"mean Δ={float(d_all.mean()):.4f}")
    plt.xlabel("P_TMI - P_standard")
    plt.ylabel("Count")
    plt.title("Test 24: Qiskit-Aer Advantage Distribution")
    plt.legend()
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test24_advantage_distribution.png", dpi=200)

    print("Overall:")
    print(overall.to_string(index=False))
    print("\nSummary by noise:")
    print(summary_noise.to_string(index=False))
    print("\nStatus:")
    print(json.dumps(status, indent=2))
    print(f"\nSaved to: {out_dir}")


if __name__ == "__main__":
    main()
