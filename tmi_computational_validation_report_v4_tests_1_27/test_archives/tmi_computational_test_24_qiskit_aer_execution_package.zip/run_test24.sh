#!/usr/bin/env bash
set -euo pipefail

python tmi_test24_qiskit_aer_execution.py --shots 1024 --n-env 2 --seed 20260506 --out smoke_test24
python tmi_test24_qiskit_aer_execution.py --shots 4096 --n-env 12 --seed 20260506 --out results_test24
