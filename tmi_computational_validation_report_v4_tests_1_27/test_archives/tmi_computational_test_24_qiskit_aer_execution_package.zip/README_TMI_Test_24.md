# TMI Computational Test 24: Real Qiskit-Aer Execution

## Purpose

This package runs the Test 23 standard-simulator protocol in real Qiskit Aer.

It compares:

- Base
- Standard fixed protection
- TMI adaptive noise-specific layer

across:

- dephasing
- depolarizing
- amplitude damping
- mixed noise

and four 3-qubit circuit families.

## Install

```bash
python -m pip install qiskit qiskit-aer numpy pandas matplotlib
```

## Run

```bash
python tmi_test24_qiskit_aer_execution.py --shots 4096 --n-env 12 --seed 20260506 --out results_test24
```

For a quick smoke test:

```bash
python tmi_test24_qiskit_aer_execution.py --shots 1024 --n-env 2 --seed 20260506 --out smoke_test24
```

## Output

The script creates:

```text
results_test24/
  data/
    tmi_test24_qiskit_aer_results.csv
    tmi_test24_summary_by_noise_model.csv
    tmi_test24_summary_by_noise_and_circuit.csv
    tmi_test24_overall.csv
  figures/
    tmi_test24_mean_success_by_noise.png
    tmi_test24_delta_by_noise.png
    tmi_test24_advantage_heatmap.png
    tmi_test24_advantage_distribution.png
  tmi_test24_status.json
```

## Main criterion

```text
P_TMI > P_standard > P_base
```

in the aggregate simulator statistics.

## Scientific caution

This is Qiskit-Aer simulator validation, not laboratory proof.
