#!/usr/bin/env python3
"""
TMI Computational Test 25: Qiskit Noise Calibration and Simulator-Interface Loss

Purpose:
  Test 24 failed in real Qiskit-Aer:
    P_standard did not improve over P_base,
    P_TMI did not improve over P_standard.

  Test 25 diagnoses the simulator-interface mapping:

    I_sim: TMI model -> Qiskit NoiseModel

  It checks:
    1. Is noise actually applied and strong enough?
    2. Are IDLE/id gates preserved by transpilation?
    3. Does standard protection improve over base when control penalty is disabled?
    4. Which Qiskit noise channel breaks or preserves the expected hierarchy?
    5. How much simulator-interface loss appears in the mapping?

Install:
  python -m pip install qiskit qiskit-aer numpy pandas matplotlib

Run smoke:
  python tmi_test25_qiskit_noise_calibration.py --shots 1024 --n-env 2 --out smoke_test25

Run full:
  python tmi_test25_qiskit_noise_calibration.py --shots 4096 --n-env 8 --out results_test25

Outputs:
  results_test25/
    data/*.csv
    figures/*.png
    tmi_test25_status.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import (
    NoiseModel,
    depolarizing_error,
    phase_damping_error,
    amplitude_damping_error,
)


N_QUBITS = 3

CIRCUITS: Dict[str, List[Tuple]] = {
    "balanced_entangle_inverse": [
        ("H", 0), ("H", 1), ("H", 2),
        ("CNOT", 0, 1), ("CNOT", 1, 2),
        ("IDLE", 2),
        ("CNOT", 1, 2), ("CNOT", 0, 1),
        ("H", 2), ("H", 1), ("H", 0),
    ],
    "ghz_inverse": [
        ("H", 0), ("CNOT", 0, 1), ("CNOT", 1, 2),
        ("IDLE", 3),
        ("CNOT", 1, 2), ("CNOT", 0, 1), ("H", 0),
    ],
}

NOISE_CHANNELS = ["phase", "depol", "amp", "mixed"]
MODES = ["base", "standard", "tmi"]


def build_circuit(spec: List[Tuple], idle_repeats_multiplier: int = 1, n_qubits: int = N_QUBITS) -> QuantumCircuit:
    qc = QuantumCircuit(n_qubits, n_qubits)
    for op in spec:
        if op[0] == "H":
            qc.h(op[1])
        elif op[0] == "X":
            qc.x(op[1])
        elif op[0] == "S":
            qc.s(op[1])
        elif op[0] == "CNOT":
            qc.cx(op[1], op[2])
        elif op[0] == "IDLE":
            duration = int(op[1]) * int(idle_repeats_multiplier)
            for _ in range(max(0, duration)):
                for q in range(n_qubits):
                    qc.id(q)
        else:
            raise ValueError(op)
    qc.measure(range(n_qubits), range(n_qubits))
    return qc


def get_counts_ops(qc: QuantumCircuit) -> Dict[str, int]:
    return {str(k): int(v) for k, v in qc.count_ops().items()}


def make_environment(rng: np.random.Generator) -> Dict[str, float]:
    return {
        "phase": float(rng.uniform(0.010, 0.028)),
        "depol": float(rng.uniform(0.002, 0.008)),
        "amp": float(rng.uniform(0.004, 0.016)),
        "control_cost_scale": float(rng.uniform(0.85, 1.25)),
    }


def protection_factors(channel: str, mode: str, env: Dict[str, float], control_penalty_scale: float) -> Tuple[float, float, float, float]:
    """
    Returns f_phase, f_depol, f_amp, control_penalty.
    Smaller factors mean stronger protection.
    """
    if mode == "base":
        return 1.0, 1.0, 1.0, 0.0

    if mode == "standard":
        return 0.72, 0.76, 0.86, 0.0008 * env["control_cost_scale"] * control_penalty_scale

    if mode == "tmi":
        if channel == "phase":
            return 0.40, 0.74, 0.86, 0.0014 * env["control_cost_scale"] * control_penalty_scale
        if channel == "depol":
            return 0.70, 0.43, 0.82, 0.0014 * env["control_cost_scale"] * control_penalty_scale
        if channel == "amp":
            return 0.73, 0.73, 0.38, 0.0015 * env["control_cost_scale"] * control_penalty_scale
        if channel == "mixed":
            return 0.53, 0.55, 0.55, 0.0016 * env["control_cost_scale"] * control_penalty_scale

    raise ValueError(f"Unknown mode/channel: {mode}/{channel}")


def safe_p(p: float, max_p: float = 0.95) -> float:
    return float(np.clip(p, 0.0, max_p))


def compose_1q_error(p_phase: float, p_depol: float, p_amp: float, active_channel: str):
    """
    Build a single-qubit error. For isolated channel tests, only one channel is active.
    For mixed, all channels are active.
    """
    if active_channel == "phase":
        return phase_damping_error(safe_p(p_phase))
    if active_channel == "depol":
        return depolarizing_error(safe_p(p_depol, 0.75), 1)
    if active_channel == "amp":
        return amplitude_damping_error(safe_p(p_amp))
    if active_channel == "mixed":
        err = phase_damping_error(safe_p(0.75 * p_phase))
        err = err.compose(depolarizing_error(safe_p(0.75 * p_depol, 0.75), 1))
        err = err.compose(amplitude_damping_error(safe_p(0.75 * p_amp)))
        return err
    raise ValueError(active_channel)


def make_noise_model(
    channel: str,
    env: Dict[str, float],
    mode: str,
    noise_scale: float,
    control_penalty_scale: float,
    idle_scale: float,
) -> NoiseModel:
    f_phase, f_depol, f_amp, penalty = protection_factors(channel, mode, env, control_penalty_scale)

    p_phase = noise_scale * env["phase"] * f_phase
    p_depol = noise_scale * env["depol"] * f_depol + penalty
    p_amp = noise_scale * env["amp"] * f_amp

    # Gate-specific errors.
    err_1q = compose_1q_error(p_phase, p_depol, p_amp, channel)
    err_idle = compose_1q_error(idle_scale * p_phase, 0.6 * idle_scale * p_depol, idle_scale * p_amp, channel)

    # Two-qubit: tensor local one-qubit channel + explicit two-qubit depolarization.
    err_2q_local = err_1q.tensor(err_1q)
    err_2q = err_2q_local.compose(depolarizing_error(safe_p(1.35 * p_depol, 0.75), 2))

    nm = NoiseModel()
    nm.add_all_qubit_quantum_error(err_1q, ["h", "x", "s"])
    nm.add_all_qubit_quantum_error(err_idle, ["id"])
    nm.add_all_qubit_quantum_error(err_2q, ["cx"])
    return nm


def run_aer(qc: QuantumCircuit, nm: NoiseModel, shots: int, seed: int, optimization_level: int = 0) -> Tuple[float, Dict[str, int]]:
    sim = AerSimulator(noise_model=nm, seed_simulator=seed)
    tqc = transpile(qc, sim, seed_transpiler=seed, optimization_level=optimization_level)
    result = sim.run(tqc, shots=shots).result()
    counts = result.get_counts()
    p000 = counts.get("000", 0) / shots
    return float(p000), get_counts_ops(tqc)


def bootstrap_ci(values, rng, n_boot=1500):
    arr = np.asarray(values, dtype=float)
    out = np.empty(n_boot)
    for i in range(n_boot):
        out[i] = np.mean(rng.choice(arr, size=len(arr), replace=True))
    return tuple(np.quantile(out, [0.025, 0.975]).astype(float))


def experiment_idle_preservation(out_dir: Path) -> pd.DataFrame:
    rows = []
    for circuit_name, spec in CIRCUITS.items():
        for mult in [0, 1, 3, 8]:
            qc = build_circuit(spec, idle_repeats_multiplier=mult)
            sim = AerSimulator()
            for opt in [0, 1, 2, 3]:
                tqc = transpile(qc, sim, optimization_level=opt)
                before = get_counts_ops(qc)
                after = get_counts_ops(tqc)
                rows.append({
                    "circuit": circuit_name,
                    "idle_repeats_multiplier": mult,
                    "optimization_level": opt,
                    "id_before": before.get("id", 0),
                    "id_after": after.get("id", 0),
                    "ops_before": json.dumps(before),
                    "ops_after": json.dumps(after),
                    "id_preserved": after.get("id", 0) >= before.get("id", 0),
                })
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "tmi_test25_idle_transpile_check.csv", index=False)
    return df


def run_calibration(args) -> None:
    out_dir = Path(args.out)
    data_dir = out_dir / "data"
    fig_dir = out_dir / "figures"
    data_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    rng_master = np.random.default_rng(args.seed)
    boot_rng = np.random.default_rng(424242)

    idle_df = experiment_idle_preservation(data_dir)

    rows = []
    compiled = {name: build_circuit(spec, idle_repeats_multiplier=args.idle_mult) for name, spec in CIRCUITS.items()}

    # Core sweeps.
    noise_scales = [0.0, 0.5, 1.0, 2.0, 4.0, 8.0]
    penalty_scales = [0.0, 0.25, 0.50, 1.0, 2.0]
    idle_scales = [0.5, 1.0, 2.0, 4.0]

    # 1) Noise strength sensitivity at default penalty.
    for circuit_name, qc in compiled.items():
        for channel in NOISE_CHANNELS:
            for noise_scale in noise_scales:
                for env_idx in range(args.n_env):
                    env_seed = int(rng_master.integers(0, 2**31 - 1))
                    env = make_environment(np.random.default_rng(env_seed))
                    probs = {}
                    op_counts = {}
                    for mode in MODES:
                        nm = make_noise_model(channel, env, mode, noise_scale, args.penalty_scale, args.idle_scale)
                        probs[mode], ops = run_aer(qc, nm, args.shots, env_seed + hash(mode) % 100000, optimization_level=args.optimization_level)
                        op_counts[mode] = ops
                    rows.append({
                        "experiment": "noise_scale_sweep",
                        "circuit": circuit_name,
                        "channel": channel,
                        "noise_scale": noise_scale,
                        "control_penalty_scale": args.penalty_scale,
                        "idle_scale": args.idle_scale,
                        "env_idx": env_idx,
                        "env_seed": env_seed,
                        "P_base": probs["base"],
                        "P_standard": probs["standard"],
                        "P_TMI": probs["tmi"],
                        "delta_standard_minus_base": probs["standard"] - probs["base"],
                        "delta_TMI_minus_standard": probs["tmi"] - probs["standard"],
                        "id_count_after": op_counts["base"].get("id", 0),
                    })

    # 2) Penalty calibration at noise_scale=4.0 where differences should be visible.
    for circuit_name, qc in compiled.items():
        for channel in NOISE_CHANNELS:
            for penalty_scale in penalty_scales:
                for env_idx in range(args.n_env):
                    env_seed = int(rng_master.integers(0, 2**31 - 1))
                    env = make_environment(np.random.default_rng(env_seed))
                    probs = {}
                    for mode in MODES:
                        nm = make_noise_model(channel, env, mode, 4.0, penalty_scale, args.idle_scale)
                        probs[mode], ops = run_aer(qc, nm, args.shots, env_seed + hash(mode) % 100000, optimization_level=args.optimization_level)
                    rows.append({
                        "experiment": "penalty_sweep",
                        "circuit": circuit_name,
                        "channel": channel,
                        "noise_scale": 4.0,
                        "control_penalty_scale": penalty_scale,
                        "idle_scale": args.idle_scale,
                        "env_idx": env_idx,
                        "env_seed": env_seed,
                        "P_base": probs["base"],
                        "P_standard": probs["standard"],
                        "P_TMI": probs["tmi"],
                        "delta_standard_minus_base": probs["standard"] - probs["base"],
                        "delta_TMI_minus_standard": probs["tmi"] - probs["standard"],
                        "id_count_after": ops.get("id", 0),
                    })

    # 3) Idle scale check at noise_scale=4 and penalty disabled.
    for circuit_name, qc in compiled.items():
        for channel in NOISE_CHANNELS:
            for idle_scale in idle_scales:
                for env_idx in range(args.n_env):
                    env_seed = int(rng_master.integers(0, 2**31 - 1))
                    env = make_environment(np.random.default_rng(env_seed))
                    probs = {}
                    for mode in MODES:
                        nm = make_noise_model(channel, env, mode, 4.0, 0.0, idle_scale)
                        probs[mode], ops = run_aer(qc, nm, args.shots, env_seed + hash(mode) % 100000, optimization_level=args.optimization_level)
                    rows.append({
                        "experiment": "idle_scale_sweep",
                        "circuit": circuit_name,
                        "channel": channel,
                        "noise_scale": 4.0,
                        "control_penalty_scale": 0.0,
                        "idle_scale": idle_scale,
                        "env_idx": env_idx,
                        "env_seed": env_seed,
                        "P_base": probs["base"],
                        "P_standard": probs["standard"],
                        "P_TMI": probs["tmi"],
                        "delta_standard_minus_base": probs["standard"] - probs["base"],
                        "delta_TMI_minus_standard": probs["tmi"] - probs["standard"],
                        "id_count_after": ops.get("id", 0),
                    })

    results = pd.DataFrame(rows)
    results.to_csv(data_dir / "tmi_test25_qiskit_calibration_results.csv", index=False)

    summary_rows = []
    group_cols = ["experiment", "channel", "noise_scale", "control_penalty_scale", "idle_scale"]
    for key, g in results.groupby(group_cols):
        exp, ch, ns, ps, iscale = key
        d_std = g["delta_standard_minus_base"]
        d_tmi = g["delta_TMI_minus_standard"]
        ci_tmi = bootstrap_ci(d_tmi, boot_rng)
        summary_rows.append({
            "experiment": exp,
            "channel": ch,
            "noise_scale": ns,
            "control_penalty_scale": ps,
            "idle_scale": iscale,
            "n": len(g),
            "mean_P_base": float(g["P_base"].mean()),
            "mean_P_standard": float(g["P_standard"].mean()),
            "mean_P_TMI": float(g["P_TMI"].mean()),
            "mean_delta_standard_minus_base": float(d_std.mean()),
            "mean_delta_TMI_minus_standard": float(d_tmi.mean()),
            "ci95_tmi_delta_low": ci_tmi[0],
            "ci95_tmi_delta_high": ci_tmi[1],
            "Pr_standard_greater_than_base": float((d_std > 0).mean()),
            "Pr_TMI_greater_than_standard": float((d_tmi > 0).mean()),
            "passed_standard_base": bool(d_std.mean() > 0 and (d_std > 0).mean() > 0.5),
            "passed_tmi_standard": bool(d_tmi.mean() > 0 and (d_tmi > 0).mean() > 0.5),
        })
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(data_dir / "tmi_test25_qiskit_calibration_summary.csv", index=False)

    # Simulator-interface loss metrics.
    # Loss_sim is high when expected hierarchy is violated.
    loss_rows = []
    for _, row in summary.iterrows():
        loss_std = max(0.0, 0.0 - row["mean_delta_standard_minus_base"])
        loss_tmi = max(0.0, 0.0 - row["mean_delta_TMI_minus_standard"])
        loss_rows.append({
            **row.to_dict(),
            "Loss_sim_standard_base": loss_std,
            "Loss_sim_TMI_standard": loss_tmi,
            "Loss_sim_total": loss_std + loss_tmi,
        })
    loss_df = pd.DataFrame(loss_rows)
    loss_df.to_csv(data_dir / "tmi_test25_simulator_interface_loss.csv", index=False)

    # Find useful calibration candidates:
    candidates = summary[
        (summary["passed_standard_base"]) &
        (summary["passed_tmi_standard"]) &
        (summary["mean_delta_TMI_minus_standard"] > 0.002)
    ].sort_values("mean_delta_TMI_minus_standard", ascending=False)
    candidates.to_csv(data_dir / "tmi_test25_candidate_calibrations.csv", index=False)

    # Overall status
    default_like = summary[
        (summary["experiment"] == "noise_scale_sweep") &
        (summary["noise_scale"] == 1.0)
    ]
    high_noise_no_penalty = summary[
        (summary["experiment"] == "penalty_sweep") &
        (summary["noise_scale"] == 4.0) &
        (summary["control_penalty_scale"] == 0.0)
    ]

    status = {
        "test": "TMI Computational Test 25: Qiskit Noise Calibration and Simulator-Interface Loss",
        "status": "calibration_completed",
        "input_context": "Test 24 failed in real Qiskit-Aer; Test 25 diagnoses the mapping.",
        "overall": {
            "n_total_runs": int(len(results)),
            "shots": int(args.shots),
            "n_env": int(args.n_env),
            "candidate_calibrations_found": int(len(candidates)),
            "default_like_mean_delta_standard_base": float(default_like["mean_delta_standard_minus_base"].mean()) if len(default_like) else None,
            "default_like_mean_delta_TMI_standard": float(default_like["mean_delta_TMI_minus_standard"].mean()) if len(default_like) else None,
            "high_noise_no_penalty_mean_delta_standard_base": float(high_noise_no_penalty["mean_delta_standard_minus_base"].mean()) if len(high_noise_no_penalty) else None,
            "high_noise_no_penalty_mean_delta_TMI_standard": float(high_noise_no_penalty["mean_delta_TMI_minus_standard"].mean()) if len(high_noise_no_penalty) else None,
            "idle_transpile_id_preservation_rate": float(idle_df["id_preserved"].mean()),
            "mean_Loss_sim_total": float(loss_df["Loss_sim_total"].mean()),
        },
        "interpretation": {
            "candidate_calibrations_found": "Number of parameter settings where standard > base and TMI > standard.",
            "Loss_sim_total": "Positive value means expected hierarchy is violated in the Qiskit mapping."
        },
        "scientific_caution": "Qiskit-Aer simulator calibration, not laboratory proof."
    }
    (out_dir / "tmi_test25_status.json").write_text(json.dumps(status, indent=2), encoding="utf-8")

    # Figures
    # Noise scale curves
    ns = summary[summary["experiment"] == "noise_scale_sweep"]
    for channel in NOISE_CHANNELS:
        g = ns[ns["channel"] == channel].groupby("noise_scale").agg(
            std_base=("mean_delta_standard_minus_base", "mean"),
            tmi_std=("mean_delta_TMI_minus_standard", "mean"),
        ).reset_index()
        plt.figure(figsize=(8.5, 5.2))
        plt.plot(g["noise_scale"], g["std_base"], marker="o", label="standard - base")
        plt.plot(g["noise_scale"], g["tmi_std"], marker="o", label="TMI - standard")
        plt.axhline(0, linestyle="--")
        plt.xlabel("noise_scale")
        plt.ylabel("Mean delta")
        plt.title(f"Test 25: Noise Scale Sensitivity ({channel})")
        plt.legend()
        plt.grid(True, alpha=0.25)
        plt.tight_layout()
        plt.savefig(fig_dir / f"tmi_test25_noise_scale_{channel}.png", dpi=200)

    # Penalty curves
    ps = summary[summary["experiment"] == "penalty_sweep"]
    for channel in NOISE_CHANNELS:
        g = ps[ps["channel"] == channel].groupby("control_penalty_scale").agg(
            std_base=("mean_delta_standard_minus_base", "mean"),
            tmi_std=("mean_delta_TMI_minus_standard", "mean"),
        ).reset_index()
        plt.figure(figsize=(8.5, 5.2))
        plt.plot(g["control_penalty_scale"], g["std_base"], marker="o", label="standard - base")
        plt.plot(g["control_penalty_scale"], g["tmi_std"], marker="o", label="TMI - standard")
        plt.axhline(0, linestyle="--")
        plt.xlabel("control_penalty_scale")
        plt.ylabel("Mean delta")
        plt.title(f"Test 25: Control Penalty Sensitivity ({channel})")
        plt.legend()
        plt.grid(True, alpha=0.25)
        plt.tight_layout()
        plt.savefig(fig_dir / f"tmi_test25_penalty_{channel}.png", dpi=200)

    # Loss heatmap for noise_scale_sweep
    pivot = loss_df[loss_df["experiment"] == "noise_scale_sweep"].pivot_table(
        index="channel",
        columns="noise_scale",
        values="Loss_sim_total",
        aggfunc="mean",
    )
    plt.figure(figsize=(9, 4.8))
    plt.imshow(pivot.values, aspect="auto", origin="lower")
    plt.colorbar(label="Mean simulator-interface loss")
    plt.yticks(range(len(pivot.index)), pivot.index)
    plt.xticks(range(len(pivot.columns)), pivot.columns)
    plt.xlabel("noise_scale")
    plt.title("Test 25: Simulator-Interface Loss Heatmap")
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test25_loss_heatmap.png", dpi=200)

    # Candidate top plot
    top = candidates.head(12).copy()
    if len(top):
        labels = [f"{r.experiment}/{r.channel}/ns={r.noise_scale}/pen={r.control_penalty_scale}/idle={r.idle_scale}" for r in top.itertuples()]
        plt.figure(figsize=(11, 6))
        plt.barh(range(len(top)), top["mean_delta_TMI_minus_standard"])
        plt.yticks(range(len(top)), labels, fontsize=7)
        plt.xlabel("Mean TMI - standard")
        plt.title("Test 25: Candidate Calibrations")
        plt.tight_layout()
        plt.savefig(fig_dir / "tmi_test25_candidate_calibrations.png", dpi=200)

    # README generated after run
    readme = f"""# TMI Computational Test 25: Qiskit Noise Calibration and Simulator-Interface Loss

## Purpose

Test 24 failed in real Qiskit-Aer. Test 25 diagnoses where the TMI effect is lost in the simulator mapping:

`I_sim: TMI model -> Qiskit NoiseModel`

## What was checked

1. Noise strength sensitivity.
2. Control penalty sensitivity.
3. Isolated channels: phase damping, depolarizing, amplitude damping, mixed.
4. Idle gate preservation through transpilation.
5. Simulator-interface loss.

## Main status

```json
{json.dumps(status, indent=2)}
```

## Important files

- `data/tmi_test25_qiskit_calibration_results.csv`
- `data/tmi_test25_qiskit_calibration_summary.csv`
- `data/tmi_test25_simulator_interface_loss.csv`
- `data/tmi_test25_candidate_calibrations.csv`
- `data/tmi_test25_idle_transpile_check.csv`
- `figures/`

## Interpretation

If `candidate_calibrations_found > 0`, then Test 24 failed because the initial mapping was uncalibrated, not because no Qiskit setting can reproduce the expected hierarchy.

If no candidates are found, the Qiskit mapping requires a more fundamental redesign.

## Scientific caution

This is simulator calibration, not laboratory proof.
"""
    (out_dir / "README_TMI_Test_25.md").write_text(readme, encoding="utf-8")

    print("Status:")
    print(json.dumps(status, indent=2))
    print("\nTop candidate calibrations:")
    if len(candidates):
        print(candidates.head(20).to_string(index=False))
    else:
        print("No candidate calibrations found.")
    print(f"\nSaved to: {out_dir}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--shots", type=int, default=4096)
    parser.add_argument("--n-env", type=int, default=8)
    parser.add_argument("--seed", type=int, default=20260506)
    parser.add_argument("--out", type=str, default="results_test25")
    parser.add_argument("--idle-mult", type=int, default=1)
    parser.add_argument("--idle-scale", type=float, default=2.0)
    parser.add_argument("--penalty-scale", type=float, default=1.0)
    parser.add_argument("--optimization-level", type=int, default=0)
    args = parser.parse_args()
    run_calibration(args)


if __name__ == "__main__":
    main()
