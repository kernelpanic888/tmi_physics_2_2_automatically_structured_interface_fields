# TMI Computational Test 25: Qiskit Noise Calibration and Simulator-Interface Loss

## Purpose

Test 24 failed in real Qiskit-Aer. Test 25 diagnoses why.

It tests the simulator-interface mapping:

```text
I_sim: TMI model -> Qiskit NoiseModel
```

The aim is to find where the expected hierarchy is lost:

```text
P_standard > P_base
P_TMI > P_standard
```

## Install

```bash
python -m pip install qiskit qiskit-aer numpy pandas matplotlib
```

## Smoke test

```bash
python tmi_test25_qiskit_noise_calibration.py --shots 1024 --n-env 2 --out smoke_test25
```

## Full run

```bash
python tmi_test25_qiskit_noise_calibration.py --shots 4096 --n-env 8 --out results_test25
```

## Faster diagnostic run

```bash
python tmi_test25_qiskit_noise_calibration.py --shots 2048 --n-env 4 --out quick_test25
```

## Output

```text
results_test25/
  data/
    tmi_test25_qiskit_calibration_results.csv
    tmi_test25_qiskit_calibration_summary.csv
    tmi_test25_simulator_interface_loss.csv
    tmi_test25_candidate_calibrations.csv
    tmi_test25_idle_transpile_check.csv
  figures/
  tmi_test25_status.json
  README_TMI_Test_25.md
```

## What to send back

After running, send:

```text
results_test25/tmi_test25_status.json
```

and the console output section:

```text
Top candidate calibrations
```

## Scientific caution

This is simulator calibration, not laboratory proof.
