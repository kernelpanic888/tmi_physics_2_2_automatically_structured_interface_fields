#!/usr/bin/env bash
set -euo pipefail

python tmi_test25_qiskit_noise_calibration.py --shots 1024 --n-env 2 --out smoke_test25
python tmi_test25_qiskit_noise_calibration.py --shots 4096 --n-env 8 --out results_test25
