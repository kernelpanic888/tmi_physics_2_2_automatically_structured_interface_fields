#!/usr/bin/env python3
"""
TMI Computational Test 27: Circuit-Inverse Correctness Audit

Purpose:
  Test 26 passed calibrated Qiskit-Aer validation, but only 12/16 circuit-channel
  cells passed. The likely weak point is phase_mix_inverse, where the inverse
  circuit used S instead of Sdg.

  Test 27 checks:
    1. Ideal inverse correctness without noise:
         P_ideal(|000>) ≈ 1
    2. Original vs corrected circuit definitions.
    3. Calibrated Qiskit-Aer validation using corrected circuits.
    4. Automatic logging to file so no screenshots/copying are needed.

Main fix:
  phase_mix_inverse:
    old inverse: ... S ...
    corrected inverse: ... Sdg ...

Install:
  python -m pip install qiskit qiskit-aer numpy pandas matplotlib

Smoke:
  python tmi_test27_circuit_inverse_audit.py --shots 1024 --n-env 2 --out smoke_test27

Full:
  python tmi_test27_circuit_inverse_audit.py --shots 4096 --n-env 12 --out results_test27

All console output is automatically saved to:
  <out>/test27_console.log
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from qiskit_aer.noise import (
    NoiseModel,
    depolarizing_error,
    phase_damping_error,
    amplitude_damping_error,
)
from qiskit.quantum_info import Statevector


N_QUBITS = 3
CHANNELS = ["phase", "depol", "amp", "mixed"]
MODES = ["base", "standard", "tmi"]


class Tee:
    """
    Duplicate stdout/stderr to terminal and log file.
    """
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for s in self.streams:
            s.write(data)
            s.flush()

    def flush(self):
        for s in self.streams:
            s.flush()


def setup_logging(out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / "test27_console.log"
    log_file = open(log_path, "w", encoding="utf-8")
    sys.stdout = Tee(sys.__stdout__, log_file)
    sys.stderr = Tee(sys.__stderr__, log_file)
    print(f"[Test 27] Console logging enabled: {log_path}")
    print(f"[Test 27] Started at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    return log_path, log_file


# Original circuits from Test 26, including suspected issue in phase_mix_inverse.
CIRCUITS_ORIGINAL: Dict[str, List[Tuple[Any, ...]]] = {
    "balanced_entangle_inverse": [
        ("H", 0), ("H", 1), ("H", 2),
        ("CNOT", 0, 1), ("CNOT", 1, 2),
        ("IDLE", 2),
        ("CNOT", 1, 2), ("CNOT", 0, 1),
        ("H", 2), ("H", 1), ("H", 0),
    ],
    "ghz_inverse": [
        ("H", 0), ("CNOT", 0, 1), ("CNOT", 1, 2),
        ("IDLE", 3),
        ("CNOT", 1, 2), ("CNOT", 0, 1), ("H", 0),
    ],
    "phase_mix_inverse": [
        ("H", 0), ("S", 0), ("H", 1), ("CNOT", 0, 2),
        ("IDLE", 2),
        ("CNOT", 0, 2), ("H", 1), ("S", 0), ("H", 0),
    ],
    "local_mix_inverse": [
        ("H", 0), ("H", 1), ("X", 2), ("H", 2),
        ("IDLE", 2),
        ("H", 2), ("X", 2), ("H", 1), ("H", 0),
    ],
}

# Corrected circuits. phase_mix_inverse uses Sdg in the inverse part.
CIRCUITS_CORRECTED: Dict[str, List[Tuple[Any, ...]]] = {
    "balanced_entangle_inverse": CIRCUITS_ORIGINAL["balanced_entangle_inverse"],
    "ghz_inverse": CIRCUITS_ORIGINAL["ghz_inverse"],
    "phase_mix_inverse": [
        ("H", 0), ("S", 0), ("H", 1), ("CNOT", 0, 2),
        ("IDLE", 2),
        ("CNOT", 0, 2), ("H", 1), ("SDG", 0), ("H", 0),
    ],
    "local_mix_inverse": CIRCUITS_ORIGINAL["local_mix_inverse"],
}

PROFILE_CONFIGS = {
    "best_by_channel": {
        "phase": {"noise_scale": 4.0, "idle_scale": 4.0, "control_penalty_scale": 0.0},
        "amp": {"noise_scale": 4.0, "idle_scale": 4.0, "control_penalty_scale": 0.0},
        "depol": {"noise_scale": 8.0, "idle_scale": 2.0, "control_penalty_scale": 1.0},
        "mixed": {"noise_scale": 4.0, "idle_scale": 2.0, "control_penalty_scale": 0.25},
    },
    "conservative": {
        "phase": {"noise_scale": 4.0, "idle_scale": 2.0, "control_penalty_scale": 0.25},
        "amp": {"noise_scale": 4.0, "idle_scale": 2.0, "control_penalty_scale": 0.25},
        "depol": {"noise_scale": 4.0, "idle_scale": 2.0, "control_penalty_scale": 0.25},
        "mixed": {"noise_scale": 4.0, "idle_scale": 2.0, "control_penalty_scale": 0.25},
    },
}


def build_circuit(
    spec: List[Tuple[Any, ...]],
    idle_repeats_multiplier: int = 1,
    n_qubits: int = N_QUBITS,
    measure: bool = True,
) -> QuantumCircuit:
    qc = QuantumCircuit(n_qubits, n_qubits if measure else 0)
    for op in spec:
        if op[0] == "H":
            qc.h(op[1])
        elif op[0] == "X":
            qc.x(op[1])
        elif op[0] == "S":
            qc.s(op[1])
        elif op[0] == "SDG":
            qc.sdg(op[1])
        elif op[0] == "CNOT":
            qc.cx(op[1], op[2])
        elif op[0] == "IDLE":
            duration = int(op[1]) * int(idle_repeats_multiplier)
            for _ in range(max(0, duration)):
                for q in range(n_qubits):
                    qc.id(q)
        else:
            raise ValueError(f"Unknown op: {op}")
    if measure:
        qc.measure(range(n_qubits), range(n_qubits))
    return qc


def build_ideal_circuit_no_idle(spec: List[Tuple[Any, ...]], n_qubits: int = N_QUBITS) -> QuantumCircuit:
    """
    For inverse correctness audit, IDLE is ignored because ideal identity does not
    change the state. We test whether the unitary part returns |000> to |000>.
    """
    spec_no_idle = [op for op in spec if op[0] != "IDLE"]
    return build_circuit(spec_no_idle, n_qubits=n_qubits, measure=False)


def ideal_p000(spec: List[Tuple[Any, ...]]) -> float:
    qc = build_ideal_circuit_no_idle(spec)
    sv = Statevector.from_instruction(qc)
    return float(abs(sv.data[0]) ** 2)


def count_ops(qc: QuantumCircuit) -> Dict[str, int]:
    return {str(k): int(v) for k, v in qc.count_ops().items()}


def make_environment(rng: np.random.Generator) -> Dict[str, float]:
    return {
        "phase": float(rng.uniform(0.010, 0.028)),
        "depol": float(rng.uniform(0.002, 0.008)),
        "amp": float(rng.uniform(0.004, 0.016)),
        "control_cost_scale": float(rng.uniform(0.85, 1.25)),
    }


def protection_factors(channel: str, mode: str, env: Dict[str, float], control_penalty_scale: float):
    if mode == "base":
        return 1.0, 1.0, 1.0, 0.0

    if mode == "standard":
        return 0.72, 0.76, 0.86, 0.0008 * env["control_cost_scale"] * control_penalty_scale

    if mode == "tmi":
        if channel == "phase":
            return 0.40, 0.74, 0.86, 0.0014 * env["control_cost_scale"] * control_penalty_scale
        if channel == "depol":
            return 0.70, 0.43, 0.82, 0.0014 * env["control_cost_scale"] * control_penalty_scale
        if channel == "amp":
            return 0.73, 0.73, 0.38, 0.0015 * env["control_cost_scale"] * control_penalty_scale
        if channel == "mixed":
            return 0.53, 0.55, 0.55, 0.0016 * env["control_cost_scale"] * control_penalty_scale

    raise ValueError(f"Unknown mode/channel: {mode}/{channel}")


def safe_p(p: float, max_p: float = 0.95) -> float:
    return float(np.clip(p, 0.0, max_p))


def compose_1q_error(p_phase: float, p_depol: float, p_amp: float, active_channel: str):
    if active_channel == "phase":
        return phase_damping_error(safe_p(p_phase))
    if active_channel == "depol":
        return depolarizing_error(safe_p(p_depol, 0.75), 1)
    if active_channel == "amp":
        return amplitude_damping_error(safe_p(p_amp))
    if active_channel == "mixed":
        err = phase_damping_error(safe_p(0.75 * p_phase))
        err = err.compose(depolarizing_error(safe_p(0.75 * p_depol, 0.75), 1))
        err = err.compose(amplitude_damping_error(safe_p(0.75 * p_amp)))
        return err
    raise ValueError(active_channel)


def make_noise_model(channel: str, env: Dict[str, float], mode: str, config: Dict[str, float]) -> NoiseModel:
    f_phase, f_depol, f_amp, penalty = protection_factors(
        channel, mode, env, config["control_penalty_scale"]
    )

    p_phase = config["noise_scale"] * env["phase"] * f_phase
    p_depol = config["noise_scale"] * env["depol"] * f_depol + penalty
    p_amp = config["noise_scale"] * env["amp"] * f_amp
    idle_scale = config["idle_scale"]

    err_1q = compose_1q_error(p_phase, p_depol, p_amp, channel)
    err_idle = compose_1q_error(idle_scale * p_phase, 0.6 * idle_scale * p_depol, idle_scale * p_amp, channel)

    err_2q_local = err_1q.tensor(err_1q)
    err_2q = err_2q_local.compose(depolarizing_error(safe_p(1.35 * p_depol, 0.75), 2))

    nm = NoiseModel()
    nm.add_all_qubit_quantum_error(err_1q, ["h", "x", "s", "sdg"])
    nm.add_all_qubit_quantum_error(err_idle, ["id"])
    nm.add_all_qubit_quantum_error(err_2q, ["cx"])
    return nm


def run_aer(qc: QuantumCircuit, nm: NoiseModel, shots: int, seed: int, optimization_level: int):
    sim = AerSimulator(noise_model=nm, seed_simulator=seed)
    tqc = transpile(qc, sim, seed_transpiler=seed, optimization_level=optimization_level)
    result = sim.run(tqc, shots=shots).result()
    counts = result.get_counts()
    return float(counts.get("000", 0) / shots), count_ops(tqc)


def bootstrap_ci(values, rng, n_boot=2000):
    arr = np.asarray(values, dtype=float)
    out = np.empty(n_boot)
    for i in range(n_boot):
        out[i] = np.mean(rng.choice(arr, size=len(arr), replace=True))
    return tuple(np.quantile(out, [0.025, 0.975]).astype(float))


def audit_inverse_correctness(out_dir: Path, tolerance: float) -> pd.DataFrame:
    rows = []
    for family_name, circuits in [("original", CIRCUITS_ORIGINAL), ("corrected", CIRCUITS_CORRECTED)]:
        for circuit_name, spec in circuits.items():
            p = ideal_p000(spec)
            rows.append({
                "family": family_name,
                "circuit": circuit_name,
                "P_ideal_000": p,
                "ideal_inverse_passed": bool(abs(1.0 - p) <= tolerance),
                "unitary_error": float(abs(1.0 - p)),
            })
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "data" / "tmi_test27_inverse_correctness_audit.csv", index=False)
    return df


def run_calibrated_validation(
    circuits: Dict[str, List[Tuple[Any, ...]]],
    args,
    out_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    data_dir = out_dir / "data"
    fig_dir = out_dir / "figures"

    rng_master = np.random.default_rng(args.seed)
    boot_rng = np.random.default_rng(424242)

    profile = PROFILE_CONFIGS[args.profile]
    compiled = {
        name: build_circuit(spec, idle_repeats_multiplier=args.idle_mult, measure=True)
        for name, spec in circuits.items()
    }

    rows = []
    for circuit_name, qc in compiled.items():
        for channel in CHANNELS:
            config = profile[channel]
            for env_idx in range(args.n_env):
                env_seed = int(rng_master.integers(0, 2**31 - 1))
                env = make_environment(np.random.default_rng(env_seed))

                probs = {}
                op_counts = {}
                for mode in MODES:
                    nm = make_noise_model(channel, env, mode, config)
                    probs[mode], ops = run_aer(
                        qc, nm, args.shots, env_seed + abs(hash(mode)) % 100000, args.optimization_level
                    )
                    op_counts[mode] = ops

                rows.append({
                    "profile": args.profile,
                    "circuit": circuit_name,
                    "channel": channel,
                    "env_idx": env_idx,
                    "env_seed": env_seed,
                    "shots": args.shots,
                    "optimization_level": args.optimization_level,
                    "noise_scale": config["noise_scale"],
                    "idle_scale": config["idle_scale"],
                    "control_penalty_scale": config["control_penalty_scale"],
                    "id_count_after": op_counts["base"].get("id", 0),
                    "ops_after_base": json.dumps(op_counts["base"]),
                    "P_base": probs["base"],
                    "P_standard": probs["standard"],
                    "P_TMI": probs["tmi"],
                    "delta_standard_minus_base": probs["standard"] - probs["base"],
                    "delta_TMI_minus_standard": probs["tmi"] - probs["standard"],
                    "delta_TMI_minus_base": probs["tmi"] - probs["base"],
                    **env,
                })

    results = pd.DataFrame(rows)

    summary_channel_rows = []
    for channel, g in results.groupby("channel"):
        d_std = g["delta_standard_minus_base"]
        d_tmi = g["delta_TMI_minus_standard"]
        ci_tmi = bootstrap_ci(d_tmi, boot_rng)
        summary_channel_rows.append({
            "channel": channel,
            "n": len(g),
            "mean_P_base": float(g["P_base"].mean()),
            "mean_P_standard": float(g["P_standard"].mean()),
            "mean_P_TMI": float(g["P_TMI"].mean()),
            "mean_delta_standard_minus_base": float(d_std.mean()),
            "mean_delta_TMI_minus_standard": float(d_tmi.mean()),
            "ci95_tmi_delta_low": ci_tmi[0],
            "ci95_tmi_delta_high": ci_tmi[1],
            "Pr_standard_greater_than_base": float((d_std > 0).mean()),
            "Pr_TMI_greater_than_standard": float((d_tmi > 0).mean()),
            "passed_standard_base": bool(d_std.mean() > 0 and (d_std > 0).mean() > 0.5),
            "passed_tmi_standard": bool(d_tmi.mean() > 0 and (d_tmi > 0).mean() > 0.5),
        })
    summary_channel = pd.DataFrame(summary_channel_rows).sort_values("channel")

    summary_cell_rows = []
    for (channel, circuit), g in results.groupby(["channel", "circuit"]):
        d_std = g["delta_standard_minus_base"]
        d_tmi = g["delta_TMI_minus_standard"]
        summary_cell_rows.append({
            "channel": channel,
            "circuit": circuit,
            "n": len(g),
            "mean_P_base": float(g["P_base"].mean()),
            "mean_P_standard": float(g["P_standard"].mean()),
            "mean_P_TMI": float(g["P_TMI"].mean()),
            "mean_delta_standard_minus_base": float(d_std.mean()),
            "mean_delta_TMI_minus_standard": float(d_tmi.mean()),
            "Pr_standard_greater_than_base": float((d_std > 0).mean()),
            "Pr_TMI_greater_than_standard": float((d_tmi > 0).mean()),
            "passed": bool(d_std.mean() > 0 and d_tmi.mean() > 0 and (d_std > 0).mean() > 0.5 and (d_tmi > 0).mean() > 0.5),
        })
    summary_cell = pd.DataFrame(summary_cell_rows).sort_values(["channel", "circuit"])

    d_std_all = results["delta_standard_minus_base"]
    d_tmi_all = results["delta_TMI_minus_standard"]
    ci_tmi_all = bootstrap_ci(d_tmi_all, boot_rng)
    ci_std_all = bootstrap_ci(d_std_all, boot_rng)

    overall = pd.DataFrame({
        "metric": [
            "profile",
            "n_total_runs",
            "shots",
            "n_env",
            "optimization_level",
            "mean_P_base",
            "mean_P_standard",
            "mean_P_TMI",
            "mean_delta_standard_minus_base",
            "ci95_std_delta_low",
            "ci95_std_delta_high",
            "mean_delta_TMI_minus_standard",
            "ci95_tmi_delta_low",
            "ci95_tmi_delta_high",
            "Pr_standard_greater_than_base",
            "Pr_TMI_greater_than_standard",
            "channels_passed_standard_base",
            "channels_passed_tmi_standard",
            "channels_total",
            "circuit_channel_cells_passed",
            "circuit_channel_cells_total",
            "mean_id_count_after",
        ],
        "value": [
            args.profile,
            len(results),
            args.shots,
            args.n_env,
            args.optimization_level,
            float(results["P_base"].mean()),
            float(results["P_standard"].mean()),
            float(results["P_TMI"].mean()),
            float(d_std_all.mean()),
            ci_std_all[0],
            ci_std_all[1],
            float(d_tmi_all.mean()),
            ci_tmi_all[0],
            ci_tmi_all[1],
            float((d_std_all > 0).mean()),
            float((d_tmi_all > 0).mean()),
            int(summary_channel["passed_standard_base"].sum()),
            int(summary_channel["passed_tmi_standard"].sum()),
            len(summary_channel),
            int(summary_cell["passed"].sum()),
            len(summary_cell),
            float(results["id_count_after"].mean()),
        ]
    })

    status = {
        "validation": "corrected_circuits_calibrated_qiskit_aer",
        "profile": args.profile,
        "profile_config": profile,
        "overall": {
            "n_total_runs": int(len(results)),
            "shots": int(args.shots),
            "mean_P_base": float(results["P_base"].mean()),
            "mean_P_standard": float(results["P_standard"].mean()),
            "mean_P_TMI": float(results["P_TMI"].mean()),
            "mean_delta_standard_minus_base": float(d_std_all.mean()),
            "ci95_std_delta": [float(ci_std_all[0]), float(ci_std_all[1])],
            "mean_delta_TMI_minus_standard": float(d_tmi_all.mean()),
            "ci95_tmi_delta": [float(ci_tmi_all[0]), float(ci_tmi_all[1])],
            "Pr_standard_greater_than_base": float((d_std_all > 0).mean()),
            "Pr_TMI_greater_than_standard": float((d_tmi_all > 0).mean()),
            "channels_passed_standard_base": int(summary_channel["passed_standard_base"].sum()),
            "channels_passed_tmi_standard": int(summary_channel["passed_tmi_standard"].sum()),
            "channels_total": int(len(summary_channel)),
            "circuit_channel_cells_passed": int(summary_cell["passed"].sum()),
            "circuit_channel_cells_total": int(len(summary_cell)),
        },
    }

    # Save
    results.to_csv(data_dir / "tmi_test27_corrected_qiskit_results.csv", index=False)
    summary_channel.to_csv(data_dir / "tmi_test27_summary_by_channel.csv", index=False)
    summary_cell.to_csv(data_dir / "tmi_test27_summary_by_channel_and_circuit.csv", index=False)
    overall.to_csv(data_dir / "tmi_test27_overall.csv", index=False)

    # Figures
    x = np.arange(len(summary_channel))
    w = 0.25
    plt.figure(figsize=(10, 5.8))
    plt.bar(x - w, summary_channel["mean_P_base"], w, label="Base")
    plt.bar(x, summary_channel["mean_P_standard"], w, label="Standard")
    plt.bar(x + w, summary_channel["mean_P_TMI"], w, label="TMI")
    plt.xticks(x, summary_channel["channel"], rotation=15, ha="right")
    plt.ylabel("Mean P_success")
    plt.title(f"Test 27: Corrected Calibrated Qiskit-Aer by Channel ({args.profile})")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test27_mean_success_by_channel.png", dpi=200)

    plt.figure(figsize=(9, 5.5))
    plt.bar(summary_channel["channel"], summary_channel["mean_delta_standard_minus_base"], alpha=0.65, label="Standard - base")
    plt.bar(summary_channel["channel"], summary_channel["mean_delta_TMI_minus_standard"], alpha=0.65, label="TMI - standard")
    plt.axhline(0, linestyle="--")
    plt.ylabel("Mean delta")
    plt.title(f"Test 27: Corrected Calibrated Advantages ({args.profile})")
    plt.legend()
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test27_deltas_by_channel.png", dpi=200)

    pivot = summary_cell.pivot(index="channel", columns="circuit", values="mean_delta_TMI_minus_standard")
    plt.figure(figsize=(11, 5.8))
    plt.imshow(pivot.values, aspect="auto", origin="lower")
    plt.colorbar(label="Mean P_TMI - P_standard")
    plt.yticks(range(len(pivot.index)), pivot.index)
    plt.xticks(range(len(pivot.columns)), pivot.columns, rotation=25, ha="right")
    plt.title(f"Test 27: Corrected TMI Advantage Heatmap ({args.profile})")
    plt.tight_layout()
    plt.savefig(fig_dir / "tmi_test27_advantage_heatmap.png", dpi=200)

    return results, summary_channel, summary_cell, overall, status


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--shots", type=int, default=4096)
    parser.add_argument("--n-env", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20260527)
    parser.add_argument("--profile", choices=list(PROFILE_CONFIGS), default="best_by_channel")
    parser.add_argument("--out", type=str, default="results_test27")
    parser.add_argument("--optimization-level", type=int, default=0)
    parser.add_argument("--idle-mult", type=int, default=1)
    parser.add_argument("--ideal-tolerance", type=float, default=1e-12)
    args = parser.parse_args()

    out_dir = Path(args.out)
    (out_dir / "data").mkdir(parents=True, exist_ok=True)
    (out_dir / "figures").mkdir(parents=True, exist_ok=True)

    log_path, log_file = setup_logging(out_dir)

    try:
        print("\n=== Test 27: Circuit-Inverse Correctness Audit ===")
        audit_df = audit_inverse_correctness(out_dir, tolerance=args.ideal_tolerance)
        print("\nInverse correctness audit:")
        print(audit_df.to_string(index=False))

        original_passed = audit_df[audit_df["family"] == "original"]["ideal_inverse_passed"].all()
        corrected_passed = audit_df[audit_df["family"] == "corrected"]["ideal_inverse_passed"].all()

        print(f"\nOriginal all ideal inverses passed: {original_passed}")
        print(f"Corrected all ideal inverses passed: {corrected_passed}")

        print("\n=== Corrected calibrated Qiskit-Aer validation ===")
        results, summary_channel, summary_cell, overall, validation_status = run_calibrated_validation(
            CIRCUITS_CORRECTED, args, out_dir
        )

        print("\nOverall:")
        print(overall.to_string(index=False))
        print("\nSummary by channel:")
        print(summary_channel.to_string(index=False))
        print("\nSummary by channel/circuit:")
        print(summary_cell.to_string(index=False))

        final_status = {
            "test": "TMI Computational Test 27: Circuit-Inverse Correctness Audit",
            "status": "passed" if corrected_passed and validation_status["overall"]["mean_delta_TMI_minus_standard"] > 0 else "failed",
            "log_file": str(log_path),
            "audit": {
                "original_all_ideal_inverses_passed": bool(original_passed),
                "corrected_all_ideal_inverses_passed": bool(corrected_passed),
                "ideal_tolerance": float(args.ideal_tolerance),
            },
            "validation": validation_status,
            "scientific_caution": "Qiskit-Aer calibrated simulator validation and circuit audit, not laboratory proof.",
        }

        (out_dir / "tmi_test27_status.json").write_text(json.dumps(final_status, indent=2), encoding="utf-8")

        readme = f"""# TMI Computational Test 27: Circuit-Inverse Correctness Audit

## Purpose

Test 26 passed calibrated Qiskit-Aer validation but only 12/16 circuit-channel cells passed.
Test 27 audits whether every circuit is a true inverse circuit in the ideal noiseless case.

## Key fix

`phase_mix_inverse` was corrected:

`S -> Sdg`

because:

`S^{-1} = Sdg`

## Output files

- `test27_console.log` — full console output
- `tmi_test27_status.json`
- `data/tmi_test27_inverse_correctness_audit.csv`
- `data/tmi_test27_corrected_qiskit_results.csv`
- `data/tmi_test27_summary_by_channel.csv`
- `data/tmi_test27_summary_by_channel_and_circuit.csv`
- `data/tmi_test27_overall.csv`
- `figures/*.png`

## Final status

```json
{json.dumps(final_status, indent=2)}
```
"""
        (out_dir / "README_TMI_Test_27.md").write_text(readme, encoding="utf-8")

        print("\nStatus:")
        print(json.dumps(final_status, indent=2))
        print(f"\nSaved to: {out_dir}")
        print(f"Full console log saved to: {log_path}")

    finally:
        print(f"[Test 27] Finished at: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        log_file.close()


if __name__ == "__main__":
    main()
