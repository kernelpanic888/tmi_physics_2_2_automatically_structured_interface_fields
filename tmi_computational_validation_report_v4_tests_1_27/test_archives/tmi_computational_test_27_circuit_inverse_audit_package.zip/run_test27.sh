#!/usr/bin/env bash
set -euo pipefail

python tmi_test27_circuit_inverse_audit.py --shots 1024 --n-env 2 --out smoke_test27
python tmi_test27_circuit_inverse_audit.py --shots 4096 --n-env 12 --out results_test27
