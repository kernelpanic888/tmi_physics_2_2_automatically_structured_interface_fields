# TMI Computational Test 27: Circuit-Inverse Correctness Audit

## Purpose

Test 26 passed calibrated Qiskit-Aer validation but only 12/16 circuit-channel cells passed.
The likely weak point was `phase_mix_inverse`.

Test 27 checks ideal inverse correctness and reruns calibrated Qiskit-Aer validation
with corrected circuits.

## Automatic output logging

The script writes the full console output automatically to:

```text
<out>/test27_console.log
```

No screenshots or manual terminal copying are needed.

## Install

```bash
python -m pip install qiskit qiskit-aer numpy pandas matplotlib
```

## Smoke test

```bash
python tmi_test27_circuit_inverse_audit.py --shots 1024 --n-env 2 --out smoke_test27
```

## Full run

```bash
python tmi_test27_circuit_inverse_audit.py --shots 4096 --n-env 12 --out results_test27
```

## Output

```text
results_test27/
  test27_console.log
  tmi_test27_status.json
  README_TMI_Test_27.md
  data/
    tmi_test27_inverse_correctness_audit.csv
    tmi_test27_corrected_qiskit_results.csv
    tmi_test27_summary_by_channel.csv
    tmi_test27_summary_by_channel_and_circuit.csv
    tmi_test27_overall.csv
  figures/
    *.png
```

## What to send back

Just send:

```text
results_test27/tmi_test27_status.json
```

or zip the whole `results_test27` directory.

The console output is already saved in:

```text
results_test27/test27_console.log
```
