# TMI Computational Test 26: Calibrated Qiskit-Aer Validation

## Purpose

Test 24 failed with the initial Qiskit-Aer mapping.
Test 25 found candidate calibrated settings where:

```text
P_TMI > P_standard > P_base
```

Test 26 performs a held-out validation run using fixed calibration profiles.

## Install

```bash
python -m pip install qiskit qiskit-aer numpy pandas matplotlib
```

## Smoke test

```bash
python tmi_test26_calibrated_qiskit_aer_validation.py --shots 1024 --n-env 2 --profile best_by_channel --out smoke_test26
```

## Full run

```bash
python tmi_test26_calibrated_qiskit_aer_validation.py --shots 4096 --n-env 12 --profile best_by_channel --out results_test26
```

## Try all profiles

```bash
for p in best_by_channel high_signal idle_exposure conservative; do
  python tmi_test26_calibrated_qiskit_aer_validation.py --shots 4096 --n-env 12 --profile "$p" --out "results_test26_$p"
done
```

## Profiles

- `best_by_channel`: uses strongest Test 25-like settings per noise channel.
- `high_signal`: uses high noise exposure.
- `idle_exposure`: emphasizes idle/noise exposure.
- `conservative`: lower-risk calibrated profile.

## Output

```text
results_test26/
  data/
    tmi_test26_calibrated_qiskit_results.csv
    tmi_test26_summary_by_channel.csv
    tmi_test26_summary_by_channel_and_circuit.csv
    tmi_test26_overall.csv
  figures/
  tmi_test26_status.json
  README_TMI_Test_26.md
```

## What to send back

Send:

```text
results_test26/tmi_test26_status.json
```

and the console blocks:

```text
Overall
Summary by channel
Status
```

## Scientific caution

This is calibrated Qiskit-Aer simulator validation, not laboratory proof.
