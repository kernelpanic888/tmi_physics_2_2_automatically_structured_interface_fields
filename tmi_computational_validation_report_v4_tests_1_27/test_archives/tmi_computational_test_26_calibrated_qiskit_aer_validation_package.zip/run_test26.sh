#!/usr/bin/env bash
set -euo pipefail

python tmi_test26_calibrated_qiskit_aer_validation.py --shots 1024 --n-env 2 --profile best_by_channel --out smoke_test26

for p in best_by_channel high_signal idle_exposure conservative; do
  python tmi_test26_calibrated_qiskit_aer_validation.py --shots 4096 --n-env 12 --profile "$p" --out "results_test26_$p"
done
