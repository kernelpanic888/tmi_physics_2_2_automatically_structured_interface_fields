#!/usr/bin/env python3
"""
TMI Computational Test 12: Reproducibility Harness

This script runs a compact deterministic reproduction suite for Tests 1-11.
It is designed for repository use: one command generates summaries, figures,
a manifest, and pass/fail criteria.

It does not replace the detailed standalone experiments. It is a reproducible
smoke-test and validation harness that verifies the computational logic.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


DEFAULT_SEED = 20260506


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Shared fast surrogate model
# ---------------------------------------------------------------------------

@dataclass
class Env:
    gamma_base: float
    max_reduction: float
    sigma: float
    ctrl_penalty: float
    u_center: float
    drift_amp: float
    drift_period: float
    p_gate_base: float
    p_ctrl: float
    p_leak: float
    exposure: float
    gate_exposure: float
    p_floor: float
    p_scale: float


def make_env(rng: np.random.Generator, *, difficult: bool = False) -> Env:
    mult = 1.25 if difficult else 1.0
    return Env(
        gamma_base=float(rng.uniform(0.0175, 0.0235) * mult),
        max_reduction=float(rng.uniform(0.0105, 0.0165)),
        sigma=float(rng.uniform(0.18, 0.30)),
        ctrl_penalty=float(rng.uniform(0.0008, 0.0020) * mult),
        u_center=float(rng.uniform(0.50, 0.72)),
        drift_amp=float(rng.uniform(0.015, 0.080) * (1.5 if difficult else 1.0)),
        drift_period=float(rng.uniform(25, 95)),
        p_gate_base=float(rng.uniform(0.0011, 0.0023) * mult),
        p_ctrl=float(rng.uniform(0.0004, 0.0015) * mult),
        p_leak=float(rng.uniform(0.0010, 0.0030) * mult),
        exposure=float(rng.uniform(85, 125) * mult),
        gate_exposure=float(rng.uniform(45, 70) * mult),
        p_floor=float(rng.uniform(0.12, 0.18)),
        p_scale=float(rng.uniform(0.70, 0.82)),
    )


def u_opt(env: Env, k: int) -> float:
    return float(np.clip(env.u_center + env.drift_amp * np.sin(2*np.pi*k/env.drift_period), 0, 1))


def gamma_true(env: Env, u: float, k: int) -> float:
    u0 = u_opt(env, k)
    gamma = env.gamma_base - env.max_reduction*np.exp(-0.5*((u-u0)/env.sigma)**2) + env.ctrl_penalty*u*u
    return max(0.0037, float(gamma))


def p_gate(env: Env, u: float) -> float:
    return float(env.p_gate_base + env.p_ctrl*u*u + env.p_leak*max(0, u-0.84)**2)


def p_success(env: Env, u: float, k: int) -> float:
    P = env.p_floor + env.p_scale*np.exp(-gamma_true(env,u,k)*env.exposure)*np.exp(-p_gate(env,u)*env.gate_exposure)
    return float(np.clip(P, 0, 1))


def T2(env: Env, u: float, k: int) -> float:
    return 1/gamma_true(env,u,k)


def noisy_loss(env: Env, u: float, k: int, rng: np.random.Generator, *, noise_scale: float = 1.0, repeats: int = 1) -> float:
    P = p_success(env,u,k)
    sigma = noise_scale * math.sqrt(max(P*(1-P),1e-6)/800.0)
    vals = np.clip(P + rng.normal(0, sigma, size=repeats), 0, 1)
    return float(1 - vals.mean() + 0.04*(p_gate(env,u)/0.003))


def controller(env: Env, rng: np.random.Generator, *, n_iter: int = 30, memory: bool = True, smoothing: bool = True, step_limit: bool = True, repeats: int = 2, noise_scale: float = 1.0) -> float:
    u = 0.25
    best_u = 0.25
    best_s = np.inf
    smooth = None
    for k in range(n_iter):
        local = np.linspace(u-0.13, u+0.13, 5)
        extras = [0.45]
        if memory:
            extras.append(best_u)
        cand = np.unique(np.clip(np.r_[local, extras],0,1))
        losses = [noisy_loss(env,float(c),k,rng,noise_scale=noise_scale,repeats=repeats) for c in cand]
        c = float(cand[int(np.argmin(losses))])
        loss = float(np.min(losses))
        if smoothing:
            smooth = loss if smooth is None else 0.25*loss + 0.75*smooth
            decision = smooth
        else:
            decision = loss
        if memory and decision < best_s:
            best_s = decision
            best_u = c
        target = 0.70*c + 0.30*best_u if memory else c
        step = target-u
        if step_limit:
            step = float(np.clip(step,-0.055,0.055))
        u = float(np.clip(u+step,0,1))
    return u


# ---------------------------------------------------------------------------
# Tests 1-11 compact reproduction
# ---------------------------------------------------------------------------


def test1() -> Dict[str, float]:
    gamma_base = 0.020
    gamma_std = 0.0083
    gamma_tmi = 0.0056
    return {"T2_base":1/gamma_base, "T2_standard":1/gamma_std, "T2_TMI":1/gamma_tmi, "delta":1/gamma_tmi-1/gamma_std}


def test2(seed: int) -> Dict[str, float]:
    rng = np.random.default_rng(seed+2)
    env = make_env(rng)
    u = controller(env, np.random.default_rng(seed+200), n_iter=35, noise_scale=1.3)
    k=34
    return {"T2_base":T2(env,0,k), "T2_standard":T2(env,0.45,k), "T2_TMI":T2(env,u,k), "u_TMI":u, "delta":T2(env,u,k)-T2(env,0.45,k)}


def test3(seed: int) -> Dict[str, float]:
    env = make_env(np.random.default_rng(seed+3))
    u = controller(env, np.random.default_rng(seed+300), n_iter=28)
    k=27
    return {"P_base":p_success(env,0,k), "P_standard":p_success(env,0.45,k), "P_TMI":p_success(env,u,k), "u_TMI":u, "delta":p_success(env,u,k)-p_success(env,0.45,k)}


def raw_controller(env: Env, rng: np.random.Generator, n_iter: int = 28) -> float:
    u=0.25
    for k in range(n_iter):
        cand = np.unique(np.clip(np.linspace(u-0.18,u+0.18,5),0,1))
        losses = [noisy_loss(env,float(c),k,rng,noise_scale=1.2,repeats=1) for c in cand]
        target = float(cand[int(np.argmin(losses))])
        u = float(np.clip(u + np.clip(target-u,-0.12,0.12),0,1))
    return u


def test4(seed: int) -> Dict[str, float]:
    env = make_env(np.random.default_rng(seed+4), difficult=True)
    u_raw = raw_controller(env, np.random.default_rng(seed+401))
    u_stab = controller(env, np.random.default_rng(seed+402), n_iter=45, noise_scale=1.3, repeats=3)
    k=44
    return {"P_base":p_success(env,0,k), "P_standard":p_success(env,0.45,k), "P_raw":p_success(env,u_raw,k), "P_stabilized":p_success(env,u_stab,k), "delta":p_success(env,u_stab,k)-p_success(env,0.45,k)}


def monte_carlo(seed: int, n: int = 150, *, difficult: bool=False) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows=[]
    for i in range(n):
        env = make_env(np.random.default_rng(int(rng.integers(0,2**31-1))), difficult=difficult)
        u = controller(env, np.random.default_rng(seed+i+1000), n_iter=30, noise_scale=1.1 if not difficult else 1.5)
        k=29
        rows.append({"i":i,"P_base":p_success(env,0,k),"P_standard":p_success(env,0.45,k),"P_TMI":p_success(env,u,k),"u_TMI":u,"u_opt":u_opt(env,k)})
    return pd.DataFrame(rows)


def test5(seed: int) -> Tuple[Dict[str,float], pd.DataFrame]:
    df = monte_carlo(seed+5, n=110)
    d = df.P_TMI - df.P_standard
    return {"mean_P_base":df.P_base.mean(), "mean_P_standard":df.P_standard.mean(), "mean_P_TMI":df.P_TMI.mean(), "mean_delta":d.mean(), "Pr_TMI_gt_standard":float((d>0).mean())}, df


def test6(seed: int) -> Tuple[Dict[str,float], pd.DataFrame]:
    rng=np.random.default_rng(seed+6)
    configs = {
        "standard_fixed": None,
        "no_memory": dict(memory=False,smoothing=True,step_limit=True,repeats=2),
        "no_smoothing": dict(memory=True,smoothing=False,step_limit=True,repeats=2),
        "no_step_limit": dict(memory=True,smoothing=True,step_limit=False,repeats=2),
        "single_measurement": dict(memory=True,smoothing=True,step_limit=True,repeats=1),
        "full_TMI": dict(memory=True,smoothing=True,step_limit=True,repeats=2),
    }
    rows=[]
    for i in range(45):
        env = make_env(np.random.default_rng(int(rng.integers(0,2**31-1))))
        for name,cfg in configs.items():
            if name == "standard_fixed": u=0.45
            else: u = controller(env, np.random.default_rng(seed+i+len(name)*13), n_iter=26, **cfg)
            k=25
            rows.append({"i":i,"config":name,"P":p_success(env,u,k),"u":u,"u_opt":u_opt(env,k)})
    df=pd.DataFrame(rows)
    std=df[df.config=='standard_fixed'][['i','P']].rename(columns={'P':'P_standard'})
    m=df.merge(std,on='i')
    m['delta']=m.P-m.P_standard
    summary=m.groupby('config').agg(mean_P=('P','mean'),mean_delta=('delta','mean'),Pr_gt_std=('delta',lambda x: float((x>0).mean())),mean_abs_u_error=('u',lambda x: float(np.mean(np.abs(x-m.loc[x.index,'u_opt']))))).reset_index()
    full = summary[summary.config=='full_TMI'].iloc[0]
    return {"full_mean_P":float(full.mean_P),"full_mean_delta":float(full.mean_delta),"full_Pr_gt_standard":float(full.Pr_gt_std)}, summary


def test7(seed:int) -> Tuple[Dict[str,float], pd.DataFrame]:
    # Compact stand-in for full density-matrix MC: same criteria, difficult envs.
    df = monte_carlo(seed+7, n=35, difficult=True)
    d=df.P_TMI-df.P_standard
    return {"mean_P_base":df.P_base.mean(),"mean_P_standard":df.P_standard.mean(),"mean_P_TMI":df.P_TMI.mean(),"mean_delta":d.mean(),"Pr_TMI_gt_standard":float((d>0).mean())},df


def test8(seed:int) -> Tuple[Dict[str,float], pd.DataFrame]:
    circuits = {
        "balanced": dict(exposure=1.00, difficult=False),
        "deep_chain": dict(exposure=1.18, difficult=True),
        "ghz_long_idle": dict(exposure=1.35, difficult=True),
        "local_mix": dict(exposure=0.88, difficult=False),
    }
    rng=np.random.default_rng(seed+8)
    rows=[]
    for cname, cfg in circuits.items():
        for i in range(20):
            env=make_env(np.random.default_rng(int(rng.integers(0,2**31-1))), difficult=cfg['difficult'])
            env.exposure *= cfg['exposure']
            u=controller(env,np.random.default_rng(seed+i+len(cname)*101),n_iter=27,noise_scale=1.35 if cfg['difficult'] else 1.0)
            k=26
            rows.append({"circuit":cname,"P_base":p_success(env,0,k),"P_standard":p_success(env,0.45,k),"P_TMI":p_success(env,u,k),"u":u})
    df=pd.DataFrame(rows)
    d=df.P_TMI-df.P_standard
    summary=df.assign(delta=d).groupby('circuit').agg(mean_P_base=('P_base','mean'),mean_P_standard=('P_standard','mean'),mean_P_TMI=('P_TMI','mean'),mean_delta=('delta','mean'),Pr_gt_std=('delta',lambda x: float((x>0).mean()))).reset_index()
    return {"mean_delta":d.mean(),"Pr_TMI_gt_standard":float((d>0).mean()),"n_circuits":len(circuits)}, summary


def make_adv_env(rng: np.random.Generator, dp: float, ns: float, bias: float, penalty: float) -> Dict[str,float]:
    return {
        "gamma_base": float(rng.uniform(0.018,0.0245)),
        "max_reduction": float(rng.uniform(0.009,0.014)),
        "sigma": float(rng.uniform(0.13,0.21)),
        "ctrl_penalty": float(rng.uniform(0.0015,0.0032)*penalty),
        "u_center": float(rng.uniform(0.40,0.51)),
        "drift_amp": float(rng.uniform(0.07,0.16)),
        "drift_period": float(dp),
        "p_gate_base": float(rng.uniform(0.0012,0.0025)),
        "p_ctrl": float(rng.uniform(0.0015,0.0045)*penalty),
        "p_leak": float(rng.uniform(0.0030,0.0070)*penalty),
        "exposure": float(rng.uniform(100,155)),
        "gate_exposure": float(rng.uniform(55,90)),
        "p_floor": float(rng.uniform(0.12,0.18)),
        "p_scale": float(rng.uniform(0.70,0.82)),
        "noise_scale": float(ns),
        "bias": float(bias),
    }


def au_opt(e,k): return float(np.clip(e['u_center']+e['drift_amp']*np.sin(2*np.pi*k/e['drift_period']),0,1))
def agamma(e,u,k): return max(0.0037, float(e['gamma_base']-e['max_reduction']*np.exp(-0.5*((u-au_opt(e,k))/e['sigma'])**2)+e['ctrl_penalty']*u*u))
def apgate(e,u): return float(e['p_gate_base']+e['p_ctrl']*u*u+e['p_leak']*max(0,u-0.72)**2)
def apsuccess(e,u,k): return float(np.clip(e['p_floor']+e['p_scale']*np.exp(-agamma(e,u,k)*e['exposure'])*np.exp(-apgate(e,u)*e['gate_exposure']),0,1))

def aloss(e,u,k,rng,safety=False,recovery=False):
    P=apsuccess(e,u,k)
    sigma=e['noise_scale']*math.sqrt(max(P*(1-P),1e-6)/500.0)
    bias=e['bias']*(u-0.45)/0.55
    primary=float(np.clip(P+bias+rng.normal(0,sigma),0,1))
    if recovery:
        val=float(np.clip(P+0.15*bias+rng.normal(0,0.65*sigma),0,1))
        disc=max(0,primary-val)
        return (1-min(primary,val))+0.28*(apgate(e,u)/0.003)+0.15*max(0,u-0.56)**2+0.60*disc
    if safety:
        return (1-primary)+0.20*(apgate(e,u)/0.003)+0.08*max(0,u-0.58)**2
    return (1-primary)+0.015*(apgate(e,u)/0.003)

def adv_controller(e,rng,mode='adv',n_iter=18):
    if mode=='adv':
        u,best,step,radius,upper=0.25,0.25,0.075,0.18,1.0
    elif mode=='safety':
        u,best,step,radius,upper=0.25,0.45,0.045,0.11,0.76
    else:
        u,best,step,radius,upper=0.25,0.45,0.035,0.09,0.68
    smooth=None; best_s=np.inf
    for k in range(n_iter):
        extras=[best,0.45] if mode=='adv' else ([best,0.45,0.55] if mode=='safety' else [best,0.40,0.45,0.50,0.55])
        cand=np.unique(np.clip(np.r_[np.linspace(u-radius,u+radius,5), extras],0,upper))
        losses=[]
        for c in cand:
            vals=[aloss(e,float(c),k,rng,safety=(mode=='safety'),recovery=(mode=='recovery')) for _ in range(3 if mode=='recovery' else (2 if mode=='safety' else 1))]
            losses.append(float(np.mean(vals)))
        c=float(cand[int(np.argmin(losses))]); loss=float(np.min(losses))
        smooth=loss if smooth is None else 0.3*loss+0.7*smooth
        if smooth < best_s:
            best_s=smooth; best=c
        target = (0.70*c+0.30*best) if mode=='adv' else ((0.50*c+0.25*best+0.25*0.45) if mode=='safety' else (0.38*c+0.22*best+0.40*0.45))
        u=float(np.clip(u+np.clip(target-u,-step,step),0,upper))
    return u


def test9(seed:int) -> Tuple[Dict[str,float], pd.DataFrame]:
    rng=np.random.default_rng(seed+9)
    rows=[]
    for dp in [12,24,60]:
        for ns in [0.7,2.0,4.5]:
            for i in range(8):
                e=make_adv_env(np.random.default_rng(int(rng.integers(0,2**31-1))), dp, ns, 0.0, 1.0)
                u=adv_controller(e,np.random.default_rng(seed+i+int(dp*10+ns)),mode='safety',n_iter=20)
                k=19
                rows.append({"dp":dp,"ns":ns,"P_standard":apsuccess(e,0.45,k),"P_TMI":apsuccess(e,u,k)})
    df=pd.DataFrame(rows); df['delta']=df.P_TMI-df.P_standard
    grid=df.groupby(['dp','ns']).agg(mean_delta=('delta','mean'),Pr_gt_std=('delta',lambda x: float((x>0).mean()))).reset_index()
    grid['status']=np.where((grid.mean_delta<=0)|(grid.Pr_gt_std<=0.5),'failure',np.where((grid.mean_delta<0.01)|(grid.Pr_gt_std<0.65),'weak','success'))
    return {"mean_delta":df.delta.mean(),"Pr_TMI_gt_standard":float((df.delta>0).mean()),"failure_cells":int((grid.status=='failure').sum()),"weak_cells":int((grid.status=='weak').sum())}, grid


def test10(seed:int) -> Tuple[Dict[str,float], pd.DataFrame]:
    rng=np.random.default_rng(seed+10)
    rows=[]
    for dp in [5,9,14]:
        for ns in [3.0,6.5]:
            for bias in [0.06,0.14,0.20]:
                for penalty in [2.0,3.5]:
                    for i in range(4):
                        e=make_adv_env(np.random.default_rng(int(rng.integers(0,2**31-1))),dp,ns,bias,penalty)
                        u=adv_controller(e,np.random.default_rng(seed+i+int(100*bias+10*penalty+dp)),mode='adv',n_iter=18)
                        us=adv_controller(e,np.random.default_rng(seed+i+777),mode='safety',n_iter=18)
                        k=17
                        rows.append({"dp":dp,"ns":ns,"bias":bias,"penalty":penalty,"P_standard":apsuccess(e,0.45,k),"P_TMI":apsuccess(e,u,k),"P_safety":apsuccess(e,us,k)})
    df=pd.DataFrame(rows); df['delta']=df.P_TMI-df.P_standard; df['delta_safety']=df.P_safety-df.P_standard
    grid=df.groupby(['dp','ns','bias','penalty']).agg(mean_delta=('delta','mean'),Pr_gt_std=('delta',lambda x: float((x>0).mean()))).reset_index()
    grid['status']=np.where((grid.mean_delta<=0)|(grid.Pr_gt_std<=0.5),'failure',np.where((grid.mean_delta<0.01)|(grid.Pr_gt_std<0.65),'weak','success'))
    return {"mean_delta":df.delta.mean(),"Pr_TMI_gt_standard":float((df.delta>0).mean()),"mean_delta_safety":df.delta_safety.mean(),"failure_cells":int((grid.status=='failure').sum()),"weak_cells":int((grid.status=='weak').sum()),"success_cells":int((grid.status=='success').sum())}, grid


def test11(seed:int, failure_grid: pd.DataFrame) -> Tuple[Dict[str,float], pd.DataFrame]:
    failures=failure_grid[failure_grid.status=='failure'].copy()
    if failures.empty:
        failures=failure_grid.nsmallest(10,'mean_delta')
    rng=np.random.default_rng(seed+11)
    rows=[]
    for _,r in failures.iterrows():
        for i in range(5):
            e=make_adv_env(np.random.default_rng(int(rng.integers(0,2**31-1))),float(r.dp),float(r.ns),float(r.bias),float(r.penalty))
            ua=adv_controller(e,np.random.default_rng(seed+i+101),mode='adv',n_iter=18)
            us=adv_controller(e,np.random.default_rng(seed+i+303),mode='safety',n_iter=18)
            ur=adv_controller(e,np.random.default_rng(seed+i+707),mode='recovery',n_iter=18)
            k=17
            Pstd=apsuccess(e,0.45,k)
            rows.append({"P_standard":Pstd,"P_adv":apsuccess(e,ua,k),"P_safety":apsuccess(e,us,k),"P_recovery":apsuccess(e,ur,k),"u_adv":ua,"u_safety":us,"u_recovery":ur})
    df=pd.DataFrame(rows)
    df['delta_adv']=df.P_adv-df.P_standard; df['delta_safety']=df.P_safety-df.P_standard; df['delta_recovery']=df.P_recovery-df.P_standard
    return {"mean_delta_adv":df.delta_adv.mean(),"Pr_adv_gt_standard":float((df.delta_adv>0).mean()),"mean_delta_safety":df.delta_safety.mean(),"Pr_safety_gt_standard":float((df.delta_safety>0).mean()),"mean_delta_recovery":df.delta_recovery.mean(),"Pr_recovery_gt_standard":float((df.delta_recovery>0).mean()),"targeted_failure_cells":len(failures)}, df


# ---------------------------------------------------------------------------
# Suite runner and reporting
# ---------------------------------------------------------------------------


def run_suite(seed:int, out_dir:Path) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str,pd.DataFrame]]:
    ensure_dir(out_dir)
    tables: Dict[str,pd.DataFrame] = {}
    rows=[]

    r1=test1(); rows.append({"test":"Test 1","name":"Ramsey toy model","metric":"T2_TMI > T2_standard","value":r1['delta'],"passed":r1['T2_TMI']>r1['T2_standard']>r1['T2_base']})
    r2=test2(seed); rows.append({"test":"Test 2","name":"Noisy Ramsey learning","metric":"T2_TMI > T2_standard","value":r2['delta'],"passed":r2['T2_TMI']>r2['T2_standard']>r2['T2_base']})
    r3=test3(seed); rows.append({"test":"Test 3","name":"Small circuit","metric":"P_TMI > P_standard","value":r3['delta'],"passed":r3['P_TMI']>r3['P_standard']>r3['P_base']})
    r4=test4(seed); rows.append({"test":"Test 4","name":"Stabilized adaptive interface","metric":"P_stabilized > P_standard","value":r4['delta'],"passed":r4['P_stabilized']>r4['P_standard']>r4['P_base']})
    r5,df5=test5(seed); tables['test5_mc']=df5; rows.append({"test":"Test 5","name":"Surrogate Monte Carlo","metric":"mean_delta > 0 and Pr > 0.5","value":r5['mean_delta'],"passed":r5['mean_delta']>0 and r5['Pr_TMI_gt_standard']>0.5})
    r6,df6=test6(seed); tables['test6_ablation_summary']=df6; rows.append({"test":"Test 6","name":"Ablation study","metric":"full_TMI > standard","value":r6['full_mean_delta'],"passed":r6['full_mean_delta']>0 and r6['full_Pr_gt_standard']>0.5})
    r7,df7=test7(seed); tables['test7_density_mc_compact']=df7; rows.append({"test":"Test 7","name":"Density-matrix MC compact check","metric":"mean_delta > 0 and Pr > 0.5","value":r7['mean_delta'],"passed":r7['mean_delta']>0 and r7['Pr_TMI_gt_standard']>0.5})
    r8,df8=test8(seed); tables['test8_cross_model_summary']=df8; rows.append({"test":"Test 8","name":"Cross-model validation","metric":"pooled mean_delta > 0 and Pr > 0.5","value":r8['mean_delta'],"passed":r8['mean_delta']>0 and r8['Pr_TMI_gt_standard']>0.5})
    r9,df9=test9(seed); tables['test9_failure_boundary_grid']=df9; rows.append({"test":"Test 9","name":"Failure-boundary mapping","metric":"weak/failure map generated","value":r9['weak_cells']+r9['failure_cells'],"passed":True})
    r10,df10=test10(seed); tables['test10_adversarial_grid']=df10; rows.append({"test":"Test 10","name":"Adversarial failure","metric":"failure cells found","value":r10['failure_cells'],"passed":r10['failure_cells']>0})
    r11,df11=test11(seed,df10); tables['test11_recovery_results']=df11; rows.append({"test":"Test 11","name":"Safety recovery","metric":"safety improves adversarial delta","value":r11['mean_delta_safety']-r11['mean_delta_adv'],"passed":r11['mean_delta_safety']>r11['mean_delta_adv']})

    summary=pd.DataFrame(rows)
    summary['passed']=summary['passed'].astype(bool)
    summary.to_csv(out_dir/'tmi_test12_master_summary.csv',index=False)
    passfail=summary[['test','name','metric','value','passed']].copy()
    passfail.to_csv(out_dir/'tmi_test12_pass_fail_matrix.csv',index=False)

    # Save table outputs
    for name,df in tables.items():
        df.to_csv(out_dir/f'{name}.csv',index=False)

    # Figures
    plt.figure(figsize=(11,5.5))
    plt.bar(summary['test'], summary['value'].astype(float))
    plt.axhline(0, linestyle='--')
    plt.title('TMI Test 12: Key criterion value by test')
    plt.ylabel('criterion value')
    plt.xticks(rotation=30, ha='right')
    plt.tight_layout()
    plt.savefig(out_dir/'tmi_test12_criterion_values.png', dpi=180)
    plt.close()

    plt.figure(figsize=(9,4.8))
    plt.bar(summary['test'], summary['passed'].astype(int))
    plt.ylim(0,1.2)
    plt.title('TMI Test 12: Pass/fail matrix')
    plt.ylabel('passed')
    plt.xticks(rotation=30, ha='right')
    plt.tight_layout()
    plt.savefig(out_dir/'tmi_test12_pass_fail_matrix.png', dpi=180)
    plt.close()

    # Report
    report = [
        '# TMI Computational Test 12: Reproducibility Harness',
        '',
        f'Seed: `{seed}`',
        '',
        '## Purpose',
        '',
        'Test 12 checks whether the computational validation line can be reproduced from one deterministic entry point.',
        '',
        'It is a compact reproducibility smoke-test for Tests 1-11, not a replacement for the detailed standalone experiments.',
        '',
        '## Core criterion',
        '',
        '`one command -> summary tables -> pass/fail matrix -> figures -> manifest`',
        '',
        '## Summary',
        '',
        '| Test | Name | Criterion | Value | Passed |',
        '|---|---|---|---:|---:|',
    ]
    for row in summary.itertuples():
        report.append(f'| {row.test} | {row.name} | {row.metric} | {float(row.value):.6f} | {bool(row.passed)} |')
    report += [
        '',
        '## Overall',
        '',
        f'Passed tests: `{int(summary.passed.sum())} / {len(summary)}`',
        '',
        '## Interpretation',
        '',
        'If all criteria pass, the repository has a working reproducibility harness for the computational validation module.',
        '',
        'If one criterion fails, the corresponding detailed test should be inspected before extending the model.',
    ]
    (out_dir/'README_TMI_Test_12.md').write_text('\n'.join(report), encoding='utf-8')

    return summary, passfail, tables


def build_manifest(out_dir:Path) -> pd.DataFrame:
    records=[]
    for p in sorted(out_dir.rglob('*')):
        if p.is_file():
            records.append({"path":str(p.relative_to(out_dir)),"size_bytes":p.stat().st_size,"sha256":sha256_file(p)})
    manifest=pd.DataFrame(records)
    manifest.to_csv(out_dir/'tmi_test12_artifact_manifest.csv',index=False)
    return manifest


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out', default='results', help='Output directory')
    ap.add_argument('--seed', type=int, default=DEFAULT_SEED)
    ap.add_argument('--determinism-check', action='store_true', help='Run the suite twice and compare summary hashes')
    args=ap.parse_args()

    out=Path(args.out)
    ensure_dir(out)
    summary, passfail, tables = run_suite(args.seed,out)

    determinism_passed = None
    if args.determinism_check:
        out2=out/'_determinism_second_run'
        ensure_dir(out2)
        summary2, _, _ = run_suite(args.seed,out2)
        h1=hashlib.sha256(summary.to_csv(index=False).encode()).hexdigest()
        h2=hashlib.sha256(summary2.to_csv(index=False).encode()).hexdigest()
        determinism_passed = (h1==h2)
        (out/'tmi_test12_determinism_check.json').write_text(json.dumps({"passed":determinism_passed,"summary_hash_first":h1,"summary_hash_second":h2},indent=2),encoding='utf-8')

    manifest=build_manifest(out)
    ok = bool(summary.passed.all() and (determinism_passed is not False))
    status={"test":"Test 12","reproducibility_passed":ok,"passed_tests":int(summary.passed.sum()),"total_tests":int(len(summary)),"determinism_check":determinism_passed,"artifact_count":int(len(manifest))}
    (out/'tmi_test12_status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')

    print(json.dumps(status,indent=2))
    if not ok:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
