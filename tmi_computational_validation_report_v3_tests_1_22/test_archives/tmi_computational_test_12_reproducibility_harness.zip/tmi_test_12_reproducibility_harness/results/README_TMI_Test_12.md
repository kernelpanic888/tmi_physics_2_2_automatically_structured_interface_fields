# TMI Computational Test 12: Reproducibility Harness

Seed: `20260506`

## Purpose

Test 12 checks whether the computational validation line can be reproduced from one deterministic entry point.

It is a compact reproducibility smoke-test for Tests 1-11, not a replacement for the detailed standalone experiments.

## Core criterion

`one command -> summary tables -> pass/fail matrix -> figures -> manifest`

## Summary

| Test | Name | Criterion | Value | Passed |
|---|---|---|---:|---:|
| Test 1 | Ramsey toy model | T2_TMI > T2_standard | 58.089501 | True |
| Test 2 | Noisy Ramsey learning | T2_TMI > T2_standard | 39.284580 | True |
| Test 3 | Small circuit | P_TMI > P_standard | 0.115109 | True |
| Test 4 | Stabilized adaptive interface | P_stabilized > P_standard | 0.026460 | True |
| Test 5 | Surrogate Monte Carlo | mean_delta > 0 and Pr > 0.5 | 0.065648 | True |
| Test 6 | Ablation study | full_TMI > standard | 0.086294 | True |
| Test 7 | Density-matrix MC compact check | mean_delta > 0 and Pr > 0.5 | 0.022935 | True |
| Test 8 | Cross-model validation | pooled mean_delta > 0 and Pr > 0.5 | 0.053579 | True |
| Test 9 | Failure-boundary mapping | weak/failure map generated | 4.000000 | True |
| Test 10 | Adversarial failure | failure cells found | 29.000000 | True |
| Test 11 | Safety recovery | safety improves adversarial delta | 0.004238 | True |

## Overall

Passed tests: `11 / 11`

## Interpretation

If all criteria pass, the repository has a working reproducibility harness for the computational validation module.

If one criterion fails, the corresponding detailed test should be inspected before extending the model.