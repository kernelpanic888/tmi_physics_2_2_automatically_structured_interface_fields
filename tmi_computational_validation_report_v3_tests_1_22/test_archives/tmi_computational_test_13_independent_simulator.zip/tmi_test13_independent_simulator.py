import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
import zipfile, json, textwrap, math, shutil

# ============================================================
# TMI Computational Test 13
# Independent Simulator Implementation
# ============================================================
#
# Goal:
# Verify the adaptive-interface advantage with an implementation independent
# from Tests 7-8. This simulator uses:
# - a declarative Qiskit/Cirq-style circuit description;
# - Kraus-style local dephasing and depolarizing channels;
# - a separate adaptive controller with grid-refinement and conservative memory;
# - an independent pass/fail summary.
#
# No external quantum SDK is required. This is a lightweight standalone simulator.

OUT = Path('/mnt/data/tmi_test_13_independent_simulator')
OUT.mkdir(parents=True, exist_ok=True)
FIG = OUT/'figures'; FIG.mkdir(exist_ok=True)
DATA = OUT/'data'; DATA.mkdir(exist_ok=True)

SEED = 20260506
rng_master = np.random.default_rng(SEED)

NQ = 3
DIM = 2**NQ

# -----------------------------
# Independent simulator core
# -----------------------------

I2 = np.eye(2, dtype=complex)
X = np.array([[0,1],[1,0]], dtype=complex)
Y = np.array([[0,-1j],[1j,0]], dtype=complex)
Z = np.array([[1,0],[0,-1]], dtype=complex)
H = (1/np.sqrt(2))*np.array([[1,1],[1,-1]], dtype=complex)


def RY(theta):
    c, s = np.cos(theta/2), np.sin(theta/2)
    return np.array([[c,-s],[s,c]], dtype=complex)


def RZ(theta):
    return np.array([[np.exp(-1j*theta/2),0],[0,np.exp(1j*theta/2)]], dtype=complex)


def kron_all(ops):
    out = np.array([[1]], dtype=complex)
    for op in ops:
        out = np.kron(out, op)
    return out


def oneq(gate, q):
    return kron_all([gate if i == q else I2 for i in range(NQ)])


def cnot(control, target):
    U = np.zeros((DIM,DIM), dtype=complex)
    for basis in range(DIM):
        bits = [(basis >> (NQ-1-i)) & 1 for i in range(NQ)]
        out = bits[:]
        if bits[control] == 1:
            out[target] ^= 1
        idx = 0
        for bit in out:
            idx = (idx<<1)|bit
        U[idx,basis] = 1.0
    return U

PRE = {
    ('H',0): oneq(H,0), ('H',1): oneq(H,1), ('H',2): oneq(H,2),
    ('X',0): oneq(X,0), ('X',1): oneq(X,1), ('X',2): oneq(X,2),
    ('Z',0): oneq(Z,0), ('Z',1): oneq(Z,1), ('Z',2): oneq(Z,2),
}
for c in range(NQ):
    for t in range(NQ):
        if c != t:
            PRE[('CNOT',c,t)] = cnot(c,t)

# Single-qubit Pauli operators embedded in full system.
PAULI_FULL = {}
for q in range(NQ):
    PAULI_FULL[('X',q)] = oneq(X,q)
    PAULI_FULL[('Y',q)] = oneq(Y,q)
    PAULI_FULL[('Z',q)] = oneq(Z,q)


def apply_unitary(rho, U):
    return U @ rho @ U.conj().T


def local_dephase(rho, q, p):
    # Phase flip channel: (1-p)rho + p Z rho Z
    Zq = PAULI_FULL[('Z',q)]
    return (1-p)*rho + p*(Zq @ rho @ Zq)


def local_depolarize(rho, q, p):
    # Local depolarizing approximation via Pauli mixture.
    Xq = PAULI_FULL[('X',q)]
    Yq = PAULI_FULL[('Y',q)]
    Zq = PAULI_FULL[('Z',q)]
    return (1-p)*rho + (p/3)*(Xq@rho@Xq + Yq@rho@Yq + Zq@rho@Zq)


def apply_idle_noise(rho, T2_us, dt_us):
    p_phase = 0.5*(1-np.exp(-dt_us/max(T2_us,1e-9)))
    for q in range(NQ):
        rho = local_dephase(rho, q, p_phase)
    return rho


def apply_gate_noise(rho, active_qubits, T2_us, dt_us, p_gate):
    # Dephase all qubits during elapsed gate time; depolarize only active qubits.
    rho = apply_idle_noise(rho, T2_us, dt_us)
    for q in active_qubits:
        rho = local_depolarize(rho, q, p_gate)
    return rho

class Circuit:
    def __init__(self, name, ops):
        self.name = name
        self.ops = ops

    def run(self, env, u, k):
        psi = np.zeros((DIM,1), dtype=complex)
        psi[0,0] = 1.0
        rho = psi @ psi.conj().T
        T2 = t2_eff(env, u, k)
        pg = p_gate(env, u)
        for op in self.ops:
            name = op[0]
            if name == 'IDLE':
                rho = apply_idle_noise(rho, T2, env['idle_us']*op[1])
            elif name == 'H':
                U = PRE[('H', op[1])]
                rho = apply_unitary(rho, U)
                rho = apply_gate_noise(rho, [op[1]], T2, env['dt1_us'], pg)
            elif name == 'X':
                U = PRE[('X', op[1])]
                rho = apply_unitary(rho, U)
                rho = apply_gate_noise(rho, [op[1]], T2, env['dt1_us'], pg)
            elif name == 'RY':
                U = oneq(RY(op[2]), op[1])
                rho = apply_unitary(rho, U)
                rho = apply_gate_noise(rho, [op[1]], T2, env['dt1_us'], 1.1*pg)
            elif name == 'RZ':
                U = oneq(RZ(op[2]), op[1])
                rho = apply_unitary(rho, U)
                rho = apply_gate_noise(rho, [op[1]], T2, env['dt1_us'], 0.8*pg)
            elif name == 'CNOT':
                U = PRE[('CNOT', op[1], op[2])]
                rho = apply_unitary(rho, U)
                rho = apply_gate_noise(rho, [op[1],op[2]], T2, env['dt2_us'], 1.55*pg)
            else:
                raise ValueError(op)
        return float(np.real(rho[0,0])), T2, pg

# Declarative circuits, separate from previous test code.
CIRCUITS = [
    Circuit('sdk_style_balanced_inverse', [
        ('H',0),('RY',1,np.pi/2),('H',2),('CNOT',0,1),('CNOT',1,2),('IDLE',1.0),
        ('CNOT',1,2),('CNOT',0,1),('H',2),('RY',1,-np.pi/2),('H',0)
    ]),
    Circuit('sdk_style_ghz_echo', [
        ('H',0),('CNOT',0,1),('CNOT',0,2),('IDLE',0.8),('X',1),('IDLE',0.8),('X',1),
        ('CNOT',0,2),('CNOT',0,1),('H',0)
    ]),
    Circuit('sdk_style_phase_chain', [
        ('H',0),('RZ',0,0.37),('H',1),('CNOT',0,1),('RY',2,0.72),('CNOT',1,2),('IDLE',1.2),
        ('CNOT',1,2),('RY',2,-0.72),('CNOT',0,1),('H',1),('RZ',0,-0.37),('H',0)
    ]),
    Circuit('sdk_style_deep_mixed_inverse', [
        ('RY',0,0.9),('H',1),('RZ',2,0.4),('CNOT',0,1),('CNOT',1,2),('IDLE',0.65),
        ('CNOT',0,2),('IDLE',0.65),('CNOT',0,2),('CNOT',1,2),('CNOT',0,1),
        ('RZ',2,-0.4),('H',1),('RY',0,-0.9)
    ]),
]

# -----------------------------
# Environment and controller
# -----------------------------

def make_env(rng, circuit_name):
    depth_scale = 1.0 + (0.10 if 'deep' in circuit_name else 0.0) + (0.06 if 'phase' in circuit_name else 0.0)
    return {
        'gamma_base': float(rng.uniform(0.0155, 0.0225)*depth_scale),
        'max_reduction': float(rng.uniform(0.0095, 0.0160)),
        'sigma': float(rng.uniform(0.15, 0.27)),
        'u_center': float(rng.uniform(0.55, 0.73)),
        'drift_amp': float(rng.uniform(0.010, 0.065)),
        'drift_period': float(rng.uniform(45, 90)),
        'control_dephase_penalty': float(rng.uniform(0.0005, 0.0015)),
        'p_gate_base': float(rng.uniform(0.00045, 0.0013)*depth_scale),
        'p_ctrl': float(rng.uniform(0.00025, 0.00095)),
        'p_leak': float(rng.uniform(0.0004, 0.0022)),
        'dt1_us': float(rng.uniform(2.4, 4.8)),
        'dt2_us': float(rng.uniform(4.8, 8.0)),
        'idle_us': float(rng.uniform(18, 42)) * (1.15 if 'ghz' in circuit_name else 1.0),
        'shots': int(rng.integers(700, 1300)),
    }


def u_opt(env,k):
    return float(np.clip(env['u_center'] + env['drift_amp']*np.sin(2*np.pi*k/env['drift_period']), 0, 1))


def gamma_eff(env,u,k):
    u0 = u_opt(env,k)
    gamma = env['gamma_base'] - env['max_reduction']*np.exp(-0.5*((u-u0)/env['sigma'])**2) + env['control_dephase_penalty']*u*u
    return max(0.0035, float(gamma))


def t2_eff(env,u,k):
    return 1.0/gamma_eff(env,u,k)


def p_gate(env,u):
    return float(env['p_gate_base'] + env['p_ctrl']*u*u + env['p_leak']*max(0,u-0.82)**2)


def observe_loss(circ, env, u, k, rng, repeats=1):
    vals=[]
    for _ in range(repeats):
        P,T2,pg = circ.run(env,u,k)
        shots = env['shots']
        P_hat = rng.binomial(shots, np.clip(P,0,1))/shots
        # Independent objective: success loss + mild gate penalty + movement risk.
        loss = (1-P_hat) + 0.035*(pg/0.0025) + 0.004*u*u
        vals.append(loss)
    return float(np.mean(vals))


def adaptive_controller(circ, env, rng, n_iter=22):
    # Independent adaptive search: coarse-to-local grid refinement with memory and fallback.
    u = 0.30
    best_u = 0.45
    best_loss = np.inf
    trust = 0.0
    for k in range(n_iter):
        if k < 5:
            candidates = np.linspace(0.25,0.82,7)
        else:
            radius = max(0.065, 0.16*(1-k/n_iter))
            local = np.linspace(u-radius, u+radius, 5)
            candidates = np.unique(np.clip(np.concatenate([local, [best_u, 0.45, 0.60]]),0.05,0.92))
        losses = [observe_loss(circ, env, float(c), k, rng, repeats=2 if k>8 else 1) for c in candidates]
        idx = int(np.argmin(losses))
        cand = float(candidates[idx])
        L = float(losses[idx])
        # Exponential memory of reliable best candidate.
        if L < best_loss:
            best_loss = L
            best_u = cand
            trust = min(1.0, trust + 0.08)
        else:
            trust = max(0.0, trust - 0.03)
        target = 0.55*cand + 0.30*best_u + 0.15*0.45
        max_step = 0.055 if trust > 0.25 else 0.035
        u = float(np.clip(u + np.clip(target-u, -max_step, max_step), 0.05, 0.92))
    return u, best_u, best_loss

# -----------------------------
# Run validation
# -----------------------------

N_ENV_PER_CIRCUIT = 18
N_ITER = 22
K_FINAL = N_ITER - 1
rows=[]

for circ in CIRCUITS:
    for rep in range(N_ENV_PER_CIRCUIT):
        seed = int(rng_master.integers(0, 2**31-1))
        env = make_env(np.random.default_rng(seed), circ.name)
        rng = np.random.default_rng(seed+9001)
        u_base = 0.0
        u_std = 0.45
        u_tmi, best_u, best_loss = adaptive_controller(circ, env, rng, n_iter=N_ITER)
        P_base,T2_base,pg_base = circ.run(env, u_base, K_FINAL)
        P_std,T2_std,pg_std = circ.run(env, u_std, K_FINAL)
        P_tmi,T2_tmi,pg_tmi = circ.run(env, u_tmi, K_FINAL)
        rows.append({
            'circuit': circ.name,
            'rep': rep,
            'seed': seed,
            'u_opt_hidden_final': u_opt(env,K_FINAL),
            'u_base': u_base,
            'u_standard': u_std,
            'u_TMI': u_tmi,
            'u_TMI_best_memory': best_u,
            'P_base': P_base,
            'P_standard': P_std,
            'P_TMI': P_tmi,
            'delta_TMI_minus_standard': P_tmi-P_std,
            'delta_TMI_minus_base': P_tmi-P_base,
            'T2_base_us': T2_base,
            'T2_standard_us': T2_std,
            'T2_TMI_us': T2_tmi,
            'p_gate_base': pg_base,
            'p_gate_standard': pg_std,
            'p_gate_TMI': pg_tmi,
        })

df = pd.DataFrame(rows)

# Summaries
summary = []
for circuit, g in df.groupby('circuit'):
    d = g['delta_TMI_minus_standard']
    summary.append({
        'circuit': circuit,
        'n_env': len(g),
        'mean_P_base': float(g.P_base.mean()),
        'mean_P_standard': float(g.P_standard.mean()),
        'mean_P_TMI': float(g.P_TMI.mean()),
        'mean_delta_TMI_minus_standard': float(d.mean()),
        'Pr_TMI_greater_than_standard': float((d>0).mean()),
        'mean_delta_TMI_minus_base': float((g.P_TMI-g.P_base).mean()),
        'Pr_TMI_greater_than_base': float((g.P_TMI>g.P_base).mean()),
        'mean_T2_base_us': float(g.T2_base_us.mean()),
        'mean_T2_standard_us': float(g.T2_standard_us.mean()),
        'mean_T2_TMI_us': float(g.T2_TMI_us.mean()),
        'mean_abs_u_error': float(np.mean(np.abs(g.u_TMI-g.u_opt_hidden_final))),
        'passed': bool(d.mean() > 0 and (d>0).mean() > 0.55),
    })
summary_df = pd.DataFrame(summary)

# Bootstrap CI for overall delta
rng_boot = np.random.default_rng(424242)
vals = df['delta_TMI_minus_standard'].to_numpy()
boots = [np.mean(rng_boot.choice(vals, size=len(vals), replace=True)) for _ in range(3000)]
ci_low, ci_high = np.quantile(boots, [0.025, 0.975])

overall = {
    'test_id': 'Test 13',
    'name': 'Independent simulator implementation',
    'n_circuit_families': len(CIRCUITS),
    'n_total_environments': len(df),
    'mean_P_base': float(df.P_base.mean()),
    'mean_P_standard': float(df.P_standard.mean()),
    'mean_P_TMI': float(df.P_TMI.mean()),
    'mean_delta_TMI_minus_standard': float(vals.mean()),
    'ci95_delta_low': float(ci_low),
    'ci95_delta_high': float(ci_high),
    'Pr_TMI_greater_than_standard': float((vals>0).mean()),
    'circuits_passed': int(summary_df.passed.sum()),
    'circuits_total': len(summary_df),
    'passed': bool(vals.mean() > 0 and ci_low > 0 and (vals>0).mean() > 0.60 and summary_df.passed.sum() >= 3),
}
overall_df = pd.DataFrame([overall])

# Write data
results_csv = DATA/'tmi_test13_independent_simulator_results.csv'
summary_csv = DATA/'tmi_test13_summary_by_circuit.csv'
overall_csv = DATA/'tmi_test13_overall.csv'
df.to_csv(results_csv,index=False)
summary_df.to_csv(summary_csv,index=False)
overall_df.to_csv(overall_csv,index=False)
(OUT/'tmi_test13_status.json').write_text(json.dumps(overall, indent=2), encoding='utf-8')

# Plots
circuits = summary_df['circuit'].tolist()
x = np.arange(len(circuits)); w=0.25
plt.figure(figsize=(12,6))
plt.bar(x-w, summary_df['mean_P_base'], w, label='Base')
plt.bar(x, summary_df['mean_P_standard'], w, label='Standard')
plt.bar(x+w, summary_df['mean_P_TMI'], w, label='TMI independent')
plt.xticks(x, [c.replace('sdk_style_','') for c in circuits], rotation=20, ha='right')
plt.ylabel('Mean P_success')
plt.title('Test 13: Independent Simulator Mean Success by Circuit')
plt.legend(); plt.tight_layout()
plt.savefig(FIG/'tmi_test13_mean_success_by_circuit.png', dpi=200)
plt.close()

plt.figure(figsize=(9,5.5))
plt.hist(vals, bins=20, alpha=0.85)
plt.axvline(0, linestyle='--', label='No advantage')
plt.axvline(vals.mean(), linestyle='-', label=f'Mean delta = {vals.mean():.4f}')
plt.xlabel('P_TMI - P_standard')
plt.ylabel('Count')
plt.title('Test 13: Independent Simulator Advantage Distribution')
plt.legend(); plt.grid(True, alpha=0.25); plt.tight_layout()
plt.savefig(FIG/'tmi_test13_delta_distribution.png', dpi=200)
plt.close()

plt.figure(figsize=(7,7))
plt.scatter(df['P_standard'], df['P_TMI'], alpha=0.75)
mn = float(min(df.P_standard.min(), df.P_TMI.min()))
mx = float(max(df.P_standard.max(), df.P_TMI.max()))
plt.plot([mn,mx],[mn,mx], linestyle='--', label='Equal performance')
plt.xlabel('P_success standard')
plt.ylabel('P_success TMI independent')
plt.title('Test 13: Paired Standard vs Independent TMI')
plt.legend(); plt.grid(True, alpha=0.25); plt.tight_layout()
plt.savefig(FIG/'tmi_test13_paired_standard_vs_tmi.png', dpi=200)
plt.close()

plt.figure(figsize=(9,5.5))
plt.bar(summary_df['circuit'].str.replace('sdk_style_','', regex=False), summary_df['mean_delta_TMI_minus_standard'])
plt.axhline(0, linestyle='--')
plt.xticks(rotation=20, ha='right')
plt.ylabel('Mean P_TMI - P_standard')
plt.title('Test 13: Mean Advantage by Independent Circuit')
plt.tight_layout()
plt.savefig(FIG/'tmi_test13_delta_by_circuit.png', dpi=200)
plt.close()

plt.figure(figsize=(7,7))
plt.scatter(df['u_opt_hidden_final'], df['u_TMI'], alpha=0.75)
plt.plot([0,1],[0,1], linestyle='--', label='Perfect tracking')
plt.xlabel('Hidden optimal u')
plt.ylabel('Learned independent TMI u')
plt.title('Test 13: Learned Parameter vs Hidden Optimum')
plt.legend(); plt.grid(True, alpha=0.25); plt.tight_layout()
plt.savefig(FIG/'tmi_test13_learned_u_vs_hidden_optimum.png', dpi=200)
plt.close()

# README and script copy
readme = f'''# TMI Computational Test 13: Independent Simulator Implementation

## Purpose

Test 13 checks whether the adaptive-interface advantage survives an implementation
that is independent from Tests 7--8.

This simulator uses:

1. Qiskit/Cirq-style declarative circuit descriptions;
2. local Kraus-style dephasing and depolarizing channels;
3. a separate adaptive controller based on grid refinement, conservative memory and fallback;
4. a standalone pass/fail criterion.

## Main criterion

`mean(P_TMI - P_standard) > 0`

and:

`Pr(P_TMI > P_standard) > 0.60`

and:

`95% bootstrap CI lower bound for mean delta > 0`

## Overall result

| Metric | Value |
|---|---:|
| Circuit families | {overall['n_circuit_families']} |
| Total environments | {overall['n_total_environments']} |
| Mean P_base | {overall['mean_P_base']:.6f} |
| Mean P_standard | {overall['mean_P_standard']:.6f} |
| Mean P_TMI | {overall['mean_P_TMI']:.6f} |
| Mean delta TMI - standard | {overall['mean_delta_TMI_minus_standard']:.6f} |
| 95% CI delta low | {overall['ci95_delta_low']:.6f} |
| 95% CI delta high | {overall['ci95_delta_high']:.6f} |
| Pr(TMI > standard) | {overall['Pr_TMI_greater_than_standard']:.6f} |
| Circuits passed | {overall['circuits_passed']} / {overall['circuits_total']} |
| Overall passed | {overall['passed']} |

## Results by circuit

| Circuit | Base | Standard | TMI | Delta | Pr(TMI > standard) | Passed |
|---|---:|---:|---:|---:|---:|---:|
''' + '\n'.join(
    f"| {r.circuit} | {r.mean_P_base:.6f} | {r.mean_P_standard:.6f} | {r.mean_P_TMI:.6f} | {r.mean_delta_TMI_minus_standard:.6f} | {r.Pr_TMI_greater_than_standard:.6f} | {r.passed} |"
    for r in summary_df.itertuples()
) + '''

## Interpretation

A positive result means that the computational advantage is less likely to be an artifact
of the original simulator architecture.

## Scientific caution

This is still a computational validation on toy quantum circuits. It is not a laboratory proof.
Its purpose is to test implementation independence.
'''
(OUT/'README_TMI_Test_13.md').write_text(readme, encoding='utf-8')

# Copy executable script into package
shutil.copy2(Path(__file__), OUT/'tmi_test13_independent_simulator.py')

# Zip
zip_path = Path('/mnt/data/tmi_computational_test_13_independent_simulator.zip')
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file():
            z.write(p, p.relative_to(OUT))

print('Overall:')
print(overall_df.to_string(index=False))
print('\nSummary by circuit:')
print(summary_df.to_string(index=False))
print('\nArchive:', zip_path)
