#!/usr/bin/env bash
set -euo pipefail

python tmi_test28_ood_qiskit_generalization.py --shots 1024 --n-env 2 --out smoke_test28
python tmi_test28_ood_qiskit_generalization.py --shots 4096 --n-env 12 --out results_test28
