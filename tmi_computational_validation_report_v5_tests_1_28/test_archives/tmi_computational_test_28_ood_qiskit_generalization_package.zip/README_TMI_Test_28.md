# TMI Computational Test 28: Out-of-Distribution Qiskit-Aer Generalization

## Purpose

Test 28 checks whether the calibrated Qiskit-Aer TMI interface generalizes to unseen circuits not used in Tests 24-27.

## Automatic logging

The full console output is saved automatically to:

```text
<out>/test28_console.log
```

## Install

```bash
python -m pip install qiskit qiskit-aer numpy pandas matplotlib
```

## Smoke test

```bash
python tmi_test28_ood_qiskit_generalization.py --shots 1024 --n-env 2 --out smoke_test28
```

## Full run

```bash
python tmi_test28_ood_qiskit_generalization.py --shots 4096 --n-env 12 --out results_test28
```

## Run all profiles

```bash
for p in best_by_channel conservative stress_high_signal; do
  python tmi_test28_ood_qiskit_generalization.py --shots 4096 --n-env 12 --profile "$p" --out "results_test28_$p"
done
```

## Output

```text
results_test28/
  test28_console.log
  tmi_test28_status.json
  README_TMI_Test_28.md
  data/
    tmi_test28_ood_inverse_audit.csv
    tmi_test28_ood_qiskit_results.csv
    tmi_test28_summary_by_channel.csv
    tmi_test28_summary_by_ood_circuit.csv
    tmi_test28_summary_by_channel_and_circuit.csv
    tmi_test28_overall.csv
  figures/
    *.png
```

## What to send back

Send only:

```text
results_test28/tmi_test28_status.json
```

or zip the whole results folder:

```bash
zip -r results_test28.zip results_test28
```

## Scientific caution

Qiskit-Aer out-of-distribution simulator test, not laboratory proof.
