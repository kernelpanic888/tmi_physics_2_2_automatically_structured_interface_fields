# TMI Computational Test 7: Full Density-Matrix Monte Carlo Validation
#
# This archive contains generated results, plots, and CSV files.
# See:
# - tmi_test7_full_density_matrix_mc_results.csv
# - tmi_test7_statistics.csv
# - README_TMI_Test_7.md
print("See CSV and PNG files in this archive.")