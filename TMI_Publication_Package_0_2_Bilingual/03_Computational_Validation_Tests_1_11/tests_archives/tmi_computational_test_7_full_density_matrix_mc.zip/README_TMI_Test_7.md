# TMI Computational Test 7: Full Density-Matrix Monte Carlo Validation

## Purpose

Test 5 used a fast circuit-level surrogate for Monte Carlo validation.
Test 7 repeats the statistical check using the full 3-qubit density-matrix
toy circuit from Tests 3 and 4.

## Main criteria

Mean advantage:

`E[P_success_TMI] > E[P_success_standard]`

Frequency advantage:

`Pr(P_success_TMI > P_success_standard) > 0.5`

## Setup

- Random environments: 45
- Full 3-qubit density-matrix simulation
- Circuit: `|000> -> entangling circuit -> inverse circuit -> ideally |000>`
- Quantity: `P_success = Pr(000)`
- Compared modes:
  - base no protection
  - standard fixed protection
  - stabilized TMI adaptive interface

## Main results

| Metric | Value |
|---|---:|
| Mean P_success base | 0.181511 |
| Mean P_success standard | 0.321896 |
| Mean P_success TMI | 0.415362 |
| Mean delta TMI - standard | 0.093467 |
| 95% bootstrap CI for delta TMI - standard | [0.073519, 0.112897] |
| Pr(TMI > standard) | 0.933333 |
| Sign-test successes | 42 / 45 |
| Sign-test z approximation | 5.814 |
| Sign-test two-sided p approximation | 6.10789e-09 |

## Interpretation

If `mean_delta_TMI_minus_standard` is positive and `Pr(TMI > standard) > 0.5`,
then the full density-matrix toy model supports the adaptive-interface mechanism.

## Scientific caution

This is still not a laboratory proof. It is a full density-matrix numerical
validation of a small toy quantum circuit under randomized hidden environments.