# TMI Computational Test 4: Stabilized Adaptive Interface
#
# This archive contains generated CSV files and plots for a stabilized adaptive
# interface test on a 3-qubit toy circuit.
#
# The stabilized interface uses:
# - memory of best parameter,
# - smoothed loss,
# - trust-region update,
# - repeated noisy measurements per candidate.
#
# Main criterion:
# P_success_stabilized > P_success_standard
#
# Stronger criterion:
# P_success_stabilized > P_success_raw
#
# See:
# - tmi_test4_summary.csv
# - tmi_test4_stabilized_history.csv
# - tmi_test4_raw_adaptive_history.csv
# - plots in this archive.
print("See CSV and PNG files in this archive.")