import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

out_dir = Path(".")
rng = np.random.default_rng(20260506)

t_us = np.linspace(0, 300, 301)
t_cal = np.array([40.0, 80.0, 120.0, 160.0])

u_base = 0.0
u_standard = 0.45
u_initial = 0.25

shot_noise_sigma = 0.015
readout_bias = 0.004

def u_optimal(iteration: int) -> float:
    return 0.62 + 0.07 * np.sin(2 * np.pi * iteration / 55.0)

def gamma_true(u: float, iteration: int) -> float:
    gamma_base = 0.020
    max_reduction = 0.0145
    sigma = 0.22
    ctrl_penalty = 0.0018
    u0 = u_optimal(iteration)
    gamma = (
        gamma_base
        - max_reduction * np.exp(-0.5 * ((u - u0) / sigma) ** 2)
        + ctrl_penalty * u ** 2
    )
    return max(0.0035, float(gamma))

def noisy_ramsey_points(u: float, iteration: int) -> np.ndarray:
    g = gamma_true(u, iteration)
    ideal = np.exp(-g * t_cal)
    measured = ideal + rng.normal(0.0, shot_noise_sigma, size=len(t_cal)) - readout_bias
    return np.clip(measured, 1e-4, 1.0)

def estimate_gamma_from_points(C_points: np.ndarray) -> float:
    slope, intercept = np.polyfit(t_cal, np.log(C_points), 1)
    return max(0.001, float(-slope))

def measured_loss(u: float, iteration: int) -> tuple[float, float]:
    C_meas = noisy_ramsey_points(u, iteration)
    gamma_hat = estimate_gamma_from_points(C_meas)
    leak_penalty = 0.0012 * max(0.0, u - 0.82) ** 2
    ctrl_penalty = 0.0007 * u ** 2
    readout_penalty = 0.00025
    L_coh = gamma_hat + leak_penalty + ctrl_penalty + readout_penalty
    return float(L_coh), float(gamma_hat)

n_iter = 90
u = u_initial
history = []

for k in range(n_iter):
    a_k = 3.0 / (1.0 + 0.025 * k)
    c_k = 0.08 / (1.0 + 0.006 * k)
    sign = 1.0 if rng.random() > 0.5 else -1.0

    u_plus = float(np.clip(u + c_k * sign, 0.0, 1.0))
    u_minus = float(np.clip(u - c_k * sign, 0.0, 1.0))

    L_plus, _ = measured_loss(u_plus, k)
    L_minus, _ = measured_loss(u_minus, k)

    grad_hat = (L_plus - L_minus) / (2.0 * c_k * sign)
    u = float(np.clip(u - a_k * grad_hat, 0.0, 1.0))

    L_current, gamma_hat = measured_loss(u, k)
    gamma_hidden = gamma_true(u, k)

    history.append({
        "iteration": k,
        "u_adaptive": u,
        "u_optimal_hidden": u_optimal(k),
        "L_coh_measured": L_current,
        "gamma_estimated_1_per_us": gamma_hat,
        "gamma_hidden_1_per_us": gamma_hidden,
        "T2_hidden_us": 1.0 / gamma_hidden,
        "gradient_estimate": grad_hat,
    })

history_df = pd.DataFrame(history)

final_iteration = n_iter - 1
gamma_base_final = gamma_true(u_base, final_iteration)
gamma_std_final = gamma_true(u_standard, final_iteration)
gamma_tmi_final = float(history_df["gamma_hidden_1_per_us"].tail(10).mean())

T2_base = 1.0 / gamma_base_final
T2_std = 1.0 / gamma_std_final
T2_tmi = 1.0 / gamma_tmi_final

C_base = np.exp(-gamma_base_final * t_us)
C_std = np.exp(-gamma_std_final * t_us)
C_tmi = np.exp(-gamma_tmi_final * t_us)

summary_df = pd.DataFrame({
    "mode": ["base_no_protection", "standard_fixed_protection", "tmi_adaptive_interface"],
    "control_parameter_u": [u_base, u_standard, float(history_df["u_adaptive"].tail(10).mean())],
    "gamma_eff_1_per_us": [gamma_base_final, gamma_std_final, gamma_tmi_final],
    "T2_eff_us": [T2_base, T2_std, T2_tmi],
    "relative_to_base": [1.0, T2_std / T2_base, T2_tmi / T2_base],
})

curves_df = pd.DataFrame({
    "time_us": t_us,
    "C_base": C_base,
    "C_standard_fixed": C_std,
    "C_TMI_adaptive": C_tmi,
})

history_df.to_csv(out_dir / "tmi_test2_adaptive_history.csv", index=False)
summary_df.to_csv(out_dir / "tmi_test2_summary.csv", index=False)
curves_df.to_csv(out_dir / "tmi_test2_ramsey_curves.csv", index=False)

plt.figure(figsize=(9, 5.5))
plt.plot(t_us, C_base, label=f"Base: T2 ≈ {T2_base:.1f} μs")
plt.plot(t_us, C_std, label=f"Standard fixed: T2 ≈ {T2_std:.1f} μs")
plt.plot(t_us, C_tmi, label=f"TMI adaptive: T2 ≈ {T2_tmi:.1f} μs")
plt.xlabel("Time, t (μs)")
plt.ylabel("Coherence, C(t)")
plt.title("TMI Test 2: Noisy Ramsey Simulation with Adaptive Control")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(out_dir / "tmi_test2_noisy_ramsey_coherence.png", dpi=200)

plt.figure(figsize=(9, 5.5))
plt.plot(history_df["iteration"], history_df["u_adaptive"], label="Adaptive interface parameter u")
plt.plot(history_df["iteration"], history_df["u_optimal_hidden"], label="Hidden optimal u in simulator")
plt.xlabel("Adaptive iteration")
plt.ylabel("Protection parameter, u")
plt.title("Adaptive Interface Learning Under Noisy Measurements")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(out_dir / "tmi_test2_adaptive_parameter_learning.png", dpi=200)

plt.figure(figsize=(9, 5.5))
plt.plot(history_df["iteration"], history_df["L_coh_measured"], label="Measured loss L_coh")
plt.xlabel("Adaptive iteration")
plt.ylabel("Loss")
plt.title("TMI Adaptive Interface: Noisy Loss History")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(out_dir / "tmi_test2_noisy_loss_history.png", dpi=200)

plt.figure(figsize=(9, 5.5))
plt.plot(history_df["iteration"], history_df["T2_hidden_us"], label="Effective T2 during adaptation")
plt.xlabel("Adaptive iteration")
plt.ylabel("Effective T2 (μs)")
plt.title("TMI Adaptive Interface: Effective T2 During Learning")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(out_dir / "tmi_test2_t2_learning_history.png", dpi=200)

print(summary_df)