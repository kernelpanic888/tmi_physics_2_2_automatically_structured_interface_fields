# TMI Computational Test 11: Safety-Aware Recovery Test

## Purpose

Test 10 showed that adaptive interface control can fail under adversarial feedback:

`AdaptiveInterface does not imply SafeInterface`

Test 11 targets only the failure cells from Test 10 and asks whether an explicit
recovery layer can restore advantage.

## Recovery mechanism

`AutoInterface + SafetyPenalty + ConservativeFallback + ValidationChannel -> SaferControl`

The recovery layer adds:

1. stronger penalty for aggressive control;
2. conservative fallback toward the standard safe policy;
3. upper bound on control parameter;
4. validation channel with weaker bias;
5. discrepancy penalty when primary feedback looks too optimistic.

## Target set

- Failure cells from Test 10: 58
- Runs per failure cell: 10
- Total recovery runs: 580

## Main results

| Mode | Mean P | Mean delta vs standard | Pr(> standard) | Failure rate | Mean u |
|---|---:|---:|---:|---:|---:|
| standard | 0.279946 | 0.000000 | 0.000000 |  | 0.450000 |
| adversarial_TMI | 0.279928 | -0.000018 | 0.477586 | 0.522414 | 0.471895 |
| safety_v1 | 0.293862 | 0.013916 | 0.617241 | 0.382759 | 0.395475 |
| recovery_v2 | 0.293228 | 0.013282 | 0.579310 | 0.420690 | 0.386368 |

## Key conclusion

Safety-aware recovery improves the targeted failure zones, but it may not eliminate
all failures. This defines a more honest engineering result:

`AutoInterface -> AdaptiveControl`

but:

`AutoInterface + SafetyLayer -> SaferAdaptiveControl`

## Cell-level recovery

Recovered cells by Recovery v2:

`31 / 58`

## Scientific caution

This is a computational stress test using the same adversarial surrogate family
as Test 10. It is not a laboratory proof. Its purpose is to evaluate a mitigation
strategy for known failure modes.
