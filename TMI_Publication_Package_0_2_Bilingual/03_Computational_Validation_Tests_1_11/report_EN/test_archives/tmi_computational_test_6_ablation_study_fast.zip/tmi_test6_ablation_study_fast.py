# TMI Computational Test 6: Ablation Study - fast interactive version
#
# This archive contains generated ablation results, plots, and CSV files.
# See:
# - tmi_test6_ablation_summary.csv
# - tmi_test6_ablation_results_with_deltas.csv
# - README_TMI_Test_6.md
print("See CSV and PNG files in this archive.")