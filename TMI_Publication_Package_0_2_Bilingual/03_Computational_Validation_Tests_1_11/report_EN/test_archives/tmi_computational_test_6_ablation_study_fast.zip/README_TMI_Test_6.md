
# TMI Computational Test 6: Ablation Study

## Purpose

This test checks which components of the stabilized TMI adaptive interface contribute
to the circuit-level advantage.

Components tested:

1. memory of the best parameter;
2. loss smoothing;
3. trust-region / step limit;
4. repeated measurements;
5. candidate search;
6. raw SPSA adaptive control.

## Monte Carlo setup

- Number of random environments: 240
- Fast circuit-level surrogate used in Test 5
- Same random environments used for all configurations
- Reduced interactive version optimized to run inside one ChatGPT turn

## Main reference criteria

Primary success:

`mean(P_success_full_TMI) > mean(P_success_standard)`

Component importance:

If removing a component reduces mean performance relative to `full_TMI`,
that component contributes to stability or performance.

## Main result

| Config | Mean P_success | Mean delta vs standard | Mean delta vs full TMI | Mean abs u error |
|---|---:|---:|---:|---:|
| standard_fixed | 0.387158 | 0.000000 | -0.067747 | 0.157049 |
| raw_spsa | 0.381482 | -0.005676 | -0.073423 | 0.140674 |
| single_measurement | 0.453986 | 0.066828 | -0.000919 | 0.025754 |
| no_step_limit | 0.454530 | 0.067372 | -0.000375 | 0.024242 |
| no_smoothing | 0.454750 | 0.067592 | -0.000155 | 0.022514 |
| no_memory | 0.453628 | 0.066470 | -0.001277 | 0.029501 |
| full_TMI | 0.454905 | 0.067747 | 0.000000 | 0.022288 |## Key interpretation

Full TMI mean P_success:

`0.454905`

Standard fixed mean P_success:

`0.387158`

Full TMI advantage over standard:

`0.067747`

This ablation identifies which stabilizing mechanisms preserve the advantage under
noisy observations and drifting hidden optima.

## Scientific caution

This is a computational ablation study, not a laboratory proof.
It tests the internal engineering logic of the TMI adaptive-interface mechanism.