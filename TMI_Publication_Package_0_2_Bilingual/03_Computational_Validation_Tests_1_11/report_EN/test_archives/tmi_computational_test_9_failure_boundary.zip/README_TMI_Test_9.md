# TMI Computational Test 9: Failure-Boundary Test

## Purpose

Previous tests focused on demonstrating when adaptive interface control works.
Test 9 does the opposite: it searches for regimes where TMI stops outperforming
standard fixed protection.

## Stress variables

1. Hidden optimum drift period:
   - lower value = faster environmental change;
   - faster drift makes adaptive tracking harder.

2. Measurement noise scale:
   - larger value = noisier observations;
   - noisier observations make the loss estimate less reliable.

## Boundary criteria

A grid cell is classified as failure if:

`mean(P_TMI - P_standard) <= 0`

or:

`Pr(P_TMI > P_standard) <= 0.5`

A grid cell is classified as weak if:

`mean(P_TMI - P_standard) < 0.015`

or:

`Pr(P_TMI > P_standard) < 0.65`

Otherwise it is classified as success.

## Overall results

| Metric | Value |
|---|---:|
| Total runs | 1008 |
| Grid cells | 36 |
| Mean delta stabilized TMI - standard | 0.060612 |
| Pr(stabilized TMI > standard) | 0.849206 |
| Mean delta degraded TMI - standard | 0.030852 |
| Pr(degraded TMI > standard) | 0.646825 |
| Failure cells for stabilized TMI | 0 |
| Weak cells for stabilized TMI | 6 |
| Success cells for stabilized TMI | 30 |

## Failure cells

No strict failure cells were found for stabilized TMI in this sweep.

## Weak cells

 drift_period  measurement_noise_scale  mean_P_standard  mean_P_TMI  mean_delta_TMI_minus_standard  Pr_TMI_greater_than_standard  mean_P_degraded_TMI  mean_delta_degraded_minus_standard  Pr_degraded_greater_than_standard  mean_abs_u_error_TMI  mean_abs_u_error_degraded status
           12                      1.0         0.433529    0.456364                       0.022836                      0.607143             0.454004                            0.020476                           0.642857              0.029412                   0.038223   weak
           12                      1.6         0.451274    0.466001                       0.014727                      0.642857             0.460202                            0.008929                           0.535714              0.029525                   0.044574   weak
           18                      5.0         0.424041    0.453525                       0.029484                      0.642857             0.417255                           -0.006786                           0.357143              0.041909                   0.106223   weak
           45                      0.5         0.435691    0.456289                       0.020598                      0.642857             0.429755                           -0.005935                           0.357143              0.021765                   0.064442   weak
           45                      1.0         0.415701    0.455620                       0.039919                      0.642857             0.413779                           -0.001922                           0.285714              0.020676                   0.087519   weak
           45                      5.0         0.424714    0.436137                       0.011423                      0.642857             0.376180                           -0.048534                           0.107143              0.053608                   0.151755   weak

## Interpretation

The failure boundary is not merely a place where the theory is wrong. It tells us
the domain of applicability of adaptive interface control. If the hidden optimum
moves too quickly or measurement noise becomes too high, an auto-interface can fail
to track the correct protection regime.

The degraded TMI controller is included to show that structural stabilization matters:
when memory, smoothing and safer search are weakened, performance drops more easily.

## Scientific caution

This is a computational stress test using a fast circuit-level surrogate.
It is not a laboratory proof. Its purpose is to map a plausible domain of validity
and failure for the adaptive-interface mechanism.