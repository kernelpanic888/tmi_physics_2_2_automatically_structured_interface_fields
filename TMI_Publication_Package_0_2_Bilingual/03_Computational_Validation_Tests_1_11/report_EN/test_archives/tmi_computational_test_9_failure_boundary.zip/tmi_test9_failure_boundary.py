# TMI Computational Test 9: Failure-Boundary Test
#
# This archive contains generated results, plots, and CSV files.
# See:
# - tmi_test9_failure_boundary_results.csv
# - tmi_test9_failure_boundary_summary_grid.csv
# - tmi_test9_failure_boundary_overall.csv
# - README_TMI_Test_9.md
print("See CSV and PNG files in this archive.")