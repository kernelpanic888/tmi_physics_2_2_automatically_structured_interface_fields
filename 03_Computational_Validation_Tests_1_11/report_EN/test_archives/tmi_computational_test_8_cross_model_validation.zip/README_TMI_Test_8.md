
# TMI Computational Test 8: Cross-Model Validation

## Purpose

Test 7 validated the TMI adaptive-interface mechanism on one full density-matrix
3-qubit toy circuit. Test 8 checks whether the advantage persists across multiple
circuit families and different idle/noise profiles.

## Circuit families

- `balanced_entangle_inverse`
- `ghz_long_idle_inverse`
- `deep_chain_inverse`
- `local_mix_inverse`

## Main criteria

Per circuit:

`mean(P_success_TMI) > mean(P_success_standard)`

and:

`Pr(P_success_TMI > P_success_standard) > 0.5`

## Setup

- Circuit families: 4
- Random environments per circuit: 26
- Total full density-matrix runs: 104
- Compared modes:
  - base no protection
  - standard fixed protection
  - stabilized TMI adaptive interface

## Overall results

| Metric | Value |
|---|---:|
| Mean P_success base | 0.291605 |
| Mean P_success standard | 0.378846 |
| Mean P_success TMI | 0.445073 |
| Mean delta TMI - standard | 0.066226 |
| 95% bootstrap CI for delta TMI - standard | [0.053949, 0.078665] |
| Pr(TMI > standard) | 0.846154 |

## Results by circuit

| Circuit | Mean base | Mean standard | Mean TMI | Mean delta TMI - standard | Pr(TMI > standard) |
|---|---:|---:|---:|---:|---:|
| balanced_entangle_inverse | 0.169273 | 0.276999 | 0.376376 | 0.099377 | 1.000000 |
| deep_chain_inverse | 0.253236 | 0.322126 | 0.377431 | 0.055304 | 0.923077 |
| ghz_long_idle_inverse | 0.495169 | 0.511898 | 0.526667 | 0.014768 | 0.461538 |
| local_mix_inverse | 0.248741 | 0.404360 | 0.499817 | 0.095456 | 1.000000 |## Interpretation

If the TMI advantage persists across circuit families, then the mechanism is less likely
to be an artifact of one specific circuit construction.

## Scientific caution

This is still a computational validation on toy quantum circuits. It is not a physical
laboratory proof and does not prove the existence of an automatically structured
interface field in nature.