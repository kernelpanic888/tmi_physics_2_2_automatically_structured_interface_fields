# TMI Computational Test 3: Small Quantum Circuit Success Probability

## Purpose

This test moves beyond a single Ramsey coherence curve and checks whether the
TMI adaptive interface can improve the practical success probability of a small
quantum circuit.

## Circuit

A 3-qubit circuit is used:

1. Start in `|000>`.
2. Apply a forward entangling circuit.
3. Apply the reverse circuit.
4. In the ideal noiseless case, the final output is `|000>`.

The measured quantity is:

`P_success = Pr(measure 000)`

## Compared modes

1. `base_no_protection`
2. `standard_fixed_protection`
3. `tmi_adaptive_interface`

## Main numerical result

- Base `P_success`: 0.182021
- Standard `P_success`: 0.386225
- TMI adaptive `P_success`: 0.431408

Effective T2 values:

- Base T2: 51.712 microseconds
- Standard T2: 130.023 microseconds
- TMI adaptive T2: 151.667 microseconds

## Criteria

Weak success:

`P_success_TMI > P_success_base`

Strong success:

`P_success_TMI > P_success_standard`

## Result

In this toy numerical test:

`P_success_TMI > P_success_standard > P_success_base`

## Scientific caution

This is still not a physical laboratory proof. It is a computational toy model
showing that the adaptive-interface mechanism can improve both coherence and
circuit-level success probability under the assumptions of the model.