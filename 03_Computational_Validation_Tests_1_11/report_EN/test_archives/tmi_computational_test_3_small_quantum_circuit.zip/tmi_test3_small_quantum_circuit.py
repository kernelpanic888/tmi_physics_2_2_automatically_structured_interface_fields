# TMI Computational Test 3
# Small quantum circuit success-probability simulation.
#
# This script was generated from the ChatGPT run.
# It uses a 3-qubit density-matrix toy model:
# |000> -> forward entangling circuit -> reverse circuit -> ideal |000>.
# Noise lowers P_success = Pr(000).
#
# To reproduce the full experiment, use the CSV files included in the archive
# or rerun the notebook/code from the conversation.
#
# A standalone version can be reconstructed from:
# - tmi_test3_adaptive_history.csv
# - tmi_test3_summary.csv
# - tmi_test3_u_scan.csv
#
# Main criterion:
# P_success_TMI > P_success_base
# Strong criterion:
# P_success_TMI > P_success_standard
print("See CSV files and plots in this archive for the generated results.")