# TMI Computational Test 5: Monte Carlo Validation - fast interactive version
#
# This archive contains generated Monte Carlo results, plots, and CSV files.
# Main criteria:
# E[P_success_TMI] > E[P_success_standard]
# Pr(P_success_TMI > P_success_standard) > 0.5
#
# See:
# - tmi_test5_monte_carlo_results.csv
# - tmi_test5_statistics.csv
# - README_TMI_Test_5.md
print("See CSV and PNG files in this archive.")