# TMI Computational Test 5: Monte Carlo Validation

## Purpose

This test checks whether the TMI stabilized adaptive interface improves circuit-level
success probability statistically across many random hidden environments.

The previous tests showed improvement in individual runs. Test 5 asks:

1. Is the mean TMI success probability larger than the standard fixed protection?
2. How often does TMI beat the standard fixed protection?

## Main criteria

Mean advantage:

`E[P_success_TMI] > E[P_success_standard]`

Frequency advantage:

`Pr(P_success_TMI > P_success_standard) > 0.5`

## Monte Carlo setup

- Number of random environments: 500
- Fast circuit-level surrogate calibrated to the previous 3-qubit toy circuit
- Hidden environment parameters randomized:
  - baseline dephasing
  - maximum possible dephasing reduction
  - protection response width
  - hidden optimal protection parameter
  - drift amplitude and period
  - gate error parameters

## Main results

| Metric | Value |
|---|---:|
| Mean P_success base | 0.244957 |
| Mean P_success standard | 0.416924 |
| Mean P_success TMI | 0.468091 |
| Mean delta TMI - standard | 0.051167 |
| 95% bootstrap CI for delta TMI - standard | [0.046616, 0.055770] |
| Pr(TMI > standard) | 0.864000 |
| Sign-test successes | 432 / 500 |
| Sign-test z approximation | 16.279 |
| Sign-test two-sided p approximation | 1.40094e-59 |

## Interpretation

If the confidence interval for `delta TMI - standard` is above zero and
`Pr(TMI > standard) > 0.5`, then the computational model supports the claim
that the stabilized adaptive interface has a statistical advantage over fixed
standard protection under the assumptions of the simulation.

## Scientific caution

This is not a laboratory proof. It is a numerical stress test of the
TMI adaptive-interface mechanism. This fast version uses a circuit-level
surrogate to make Monte Carlo validation feasible in an interactive session.